package ic2.api.item;

import net.minecraft.item.ItemStack;

public interface IBlockCuttingBlade {
	int getHardness(ItemStack stack);
}
