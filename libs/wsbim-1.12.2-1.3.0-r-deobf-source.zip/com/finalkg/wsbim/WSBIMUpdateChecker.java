package com.finalkg.wsbim;

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.JFileChooser;

import org.apache.logging.log4j.Logger;

import net.minecraft.server.MinecraftServer;
import net.minecraftforge.fml.common.FMLCommonHandler;

/**
 * Handles almost everything needed for checking and downloading updates on the server side.
 * I will later create a way for this to work with client sided GUIs.
 * 
 * @author finalkg
 *
 */
public class WSBIMUpdateChecker {
	
	//public static String currentModFileLocation = FMLCommonHandler.instance().getSide() == Side.SERVER?MinecraftServer.getServer().getFile("")+"\\wsbim" : Minecraft.getMinecraft().mcDataDir.getPath()+"\\wsbim";
	public static File currentModFileDirectory = getJarDir(WSBIM.class);
	/**The file download url for getting information about the latest update // AS OF 1.12 THIS FILE IS HOSTED ON GOOGLE DRIVE.*/
	protected String updateMetaDataFileDownloadURL;
	/**Version of WSBIM from the update check metadata file.*/
	public String updateCheckVersion;
	/**Version of minecraft from the update check file.*/
	public String updateCheckMCVersion;
	/**Update metadata file*/
	public File updateMetadataFile;
	/**Update download url (from metadata file)*/
	public String updateFileDownloadURL;
	/**Is an update needed? (Mainly used for client end stuff)*/
	public boolean updateNeeded = false;
	/**Mod forums link*/
	private String modLink;
	
	public final String MODID;
	public final String MOD_NAME;
	public final String VERSION;
	public final String UPDATE_UI_LINE_1_UNLOCALIZED;
	public final String UPDATE_UI_LINE_2_UNLOCALIZED;
	public final String UPDATE_UI_LINE_3_UNLOCALIZED;
	public final char BUILDTYPE;
	private final Logger modLogger;
	
	/**
	 * Create this in pre-init after logger is initialized. 
	 * Uses default UPDATE_UI_strings.
	 * @param modid
	 * @param modName
	 * @param VERSION
	 * MUST FOLLOW THIS FORMAT: VERSION = "mc_version-"+MASTER_BUILD_NUMBER+"."+REVISION_NUMBER+"."+BUILD_NUMBER+"-"+BUILD_TYPE
	 * @param BUILDTYPE
	 * @param modLogger
	 * @param updateMetaDataFileDownloadURL - direct download url to update-check file.
	 */
	public WSBIMUpdateChecker(String modid, String modName, String VERSION, char BUILDTYPE, Logger modLogger, String updateMetaDataFileDownloadURL) {
		this.MODID = modid;
		this.MOD_NAME = modName;
		this.VERSION = VERSION;
		this.BUILDTYPE = BUILDTYPE;
		this.modLogger = modLogger;
		this.updateMetaDataFileDownloadURL = updateMetaDataFileDownloadURL;
		this.UPDATE_UI_LINE_1_UNLOCALIZED = "gui.wsbim.update.line1";
		this.UPDATE_UI_LINE_2_UNLOCALIZED = "gui.wsbim.update.line2";
		this.UPDATE_UI_LINE_3_UNLOCALIZED = "gui.wsbim.update.line3";
	}
	public WSBIMUpdateChecker(String modid, String modName, String VERSION, char BUILDTYPE, Logger modLogger, String updateMetaDataFileDownloadURL, String UPDATE_UI_LINE_1_UNLOCALIZED, String UPDATE_UI_LINE_2_UNLOCALIZED, String UPDATE_UI_LINE_3_UNLOCALIZED) {
		this.MODID = modid;
		this.MOD_NAME = modName;
		this.VERSION = VERSION;
		this.BUILDTYPE = BUILDTYPE;
		this.modLogger = modLogger;
		this.updateMetaDataFileDownloadURL = updateMetaDataFileDownloadURL;
		this.UPDATE_UI_LINE_1_UNLOCALIZED = UPDATE_UI_LINE_1_UNLOCALIZED;
		this.UPDATE_UI_LINE_2_UNLOCALIZED = UPDATE_UI_LINE_2_UNLOCALIZED;
		this.UPDATE_UI_LINE_3_UNLOCALIZED = UPDATE_UI_LINE_3_UNLOCALIZED;
	}
	
	/**This method resets all of the values retrieved by previous update check files*/
	public void resetData(){
		updateCheckVersion = null;
		updateCheckMCVersion = null;
		updateMetadataFile = null;
		updateFileDownloadURL = null;
		updateNeeded = false;
		modLink = null;
	}
	/**Redirects you to the mod forums...*/
	public String getModForumsLink() {
		return modLink;
	}
	/**Has a link to be viewed on the forums?*/
	public boolean hasModForumsLink() {return getModForumsLink() !=null;}
	/**This method will handle everything for running the update check on a minecraft server*/
	public void checkUpdateForServer(){
		int result = updateCheckInit(true); // This will check for a mod update for servers upon startup. 
		if(result == 0){modLogger.warn("["+MODID+"] Update check failed for an unknown reason.");}
		if(result == 1){modLogger.info("["+MODID+"] No update needed for "+MOD_NAME+". Check successful");}
		if(result == 2){
			int option = javax.swing.JOptionPane.showConfirmDialog(null, "Version "+this.updateCheckMCVersion+"-"+this.updateCheckVersion+" has been found for "+MOD_NAME+". Would you like to download it now?", "WSBIM Update Checker", javax.swing.JOptionPane.YES_NO_OPTION);
			if(option == javax.swing.JOptionPane.YES_OPTION){
				//Run our update stuff.
				this.downloadUpdateThroughDesktop(true);
			}
			else{
				modLogger.warn("["+MODID+"] User has chosen not to update "+MOD_NAME+".");
			}
		}
		if(result == 3){}
	}
	/**
	 * 
	 * This will handle downloading WSBIM updates through the desktop. It uses java swing to do so.
	 * 
	 */
	public boolean downloadUpdateThroughDesktop(boolean isServer){
		
		//javax.swing.JOptionPane.showMessageDialog(null, "In this next dialog, you will have to select your WSBIM mod file (Typically named WSBIM-VERSION.jar)", "WSBIM Update Checker", javax.swing.JOptionPane.INFORMATION_MESSAGE);
		InformationMessage mess = new InformationMessage(InformationMessage.linee1, InformationMessage.linee2);
		mess.setFocusableWindowState(true);
		mess.setFocusable(true);
		mess.toFront();
		mess.setVisible(true);
		mess.setAlwaysOnTop(true);
		
			File newModFile = new File(currentModFileDirectory, MODID+"-"+this.updateCheckMCVersion+"-"+this.updateCheckVersion+".jar");
			final DownloaderUpdateFile fileDownload = new DownloaderUpdateFile(this.updateFileDownloadURL, newModFile.getPath(), MODID+"-"+this.updateCheckMCVersion+"-"+this.updateCheckVersion+".jar", false, true);
			fileDownload.start();
			if(fileDownload.isDone()){
				//Then we notify the user that the update has finished.
				String[] strings = {this.MOD_NAME+" Version " + this.updateCheckVersion + " was successfully installed.", "WSBIM will now shut down your minecraft and you will have to run it again."};
				if(!isServer) net.minecraft.client.Minecraft.getMinecraft().setIngameNotInFocus();
				//javax.swing.JOptionPane.showMessageDialog(null, strings, "WSBIM Update Checker", javax.swing.JOptionPane.INFORMATION_MESSAGE);
				InformationMessage mess2 = new InformationMessage(this.MOD_NAME+" Version " + this.updateCheckVersion + " was successfully installed. WSBIM will now shut down your minecraft", " and you will have to run it again.");
				mess2.setBounds(0,0, 650, 120);
				final Toolkit toolkit = Toolkit.getDefaultToolkit();
				final Dimension screenSize = toolkit.getScreenSize();
				final int x = (screenSize.width - mess2.getWidth()) / 2;
				final int y = (screenSize.height - mess2.getHeight()) / 2;
				mess2.setLocation(x, y);
				mess2.setFocusableWindowState(true);
				mess2.setFocusable(true);
				mess2.toFront();
				mess2.setVisible(true);
				mess2.setAlwaysOnTop(true);
				InformationMessage mess3 = new InformationMessage("You also have to delete the old verison of the mod from your mods folder after minecraft closes.", null);
				mess3.setBounds(0,0, 700, 120);
				final Toolkit toolkit2 = Toolkit.getDefaultToolkit();
				final Dimension screenSize2 = toolkit2.getScreenSize();
				final int x2 = (screenSize2.width - mess2.getWidth()) / 2;
				final int y2 = (screenSize2.height - mess2.getHeight()) / 2;
				mess3.setLocation(x2, y2);
				mess3.setFocusableWindowState(true);
				mess3.setFocusable(true);
				mess3.toFront();
				mess3.setVisible(true);
				mess3.setAlwaysOnTop(true);
				try {
					Desktop.getDesktop().open(currentModFileDirectory);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if(isServer)FMLCommonHandler.instance().exitJava(0, true);
				return true;
				
			}
			else{
				javax.swing.JOptionPane.showMessageDialog(null, MOD_NAME+" has failed to download the update. Sorry. Your minecraft will continue to run.", MODID+" Update Checker", javax.swing.JOptionPane.ERROR_MESSAGE);
				return false;
			}
	}
	 /**
     * Get the extension of a file. Courtesy of docs.oracle.com
     */  
    public static String getExtension(File f) {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        return ext;
    }
	/**
	 * This will run an update check on the currently running version of WSBIM. 
	 * If it is needed, we will use the windows dialog boxes to do this.
	 * If the update check is happening on the client end, we will do this in 
	 * minecraft's dedicated gui system.
	 * @param isServer 
	 * @return The outcome of the update check. 0 means fail (or unknown error), 1 means successful (or no update needed), 2 means update needed, and 3 means download failed.
	 * 
	 */
	public int updateCheckInit(boolean isServer){
		modLogger.info("["+MODID+"] Checking for updates. Downloading File");
		String downloadUrl = updateMetaDataFileDownloadURL;
		updateMetadataFile = new File(WSBIM.options.wsbimFolder, MODID+"_update.txt");
		if(updateMetadataFile.exists()){
			updateMetadataFile.delete();
		}
		final DownloaderUpdateFile fileDownload = new DownloaderUpdateFile(downloadUrl, updateMetadataFile.getPath(), MODID+"_update.txt", false, isServer);
		fileDownload.start();
		if(fileDownload.isDone()){
			
			try {
				if(this.extractMetadataFileInformation(updateMetadataFile)){
					String[] versions = this.updateCheckVersion.split("-");
					String[] current_versions = VERSION.split("-");
					String modVersion = current_versions[1];
					String mcVersion = current_versions[0];
					String updateModVersion = versions[0];
					char buildType = versions.length > 1 ? versions[1].toCharArray()[0] : ' ';
					Version current = new Version(modVersion);
					Version found = new Version(updateModVersion);
					//DEBUGGING javax.swing.JOptionPane.showMessageDialog(null, new String[]{"Current:"+modVersionNumber, "Update:"+foundModVersionNumber});
					if(current.equals(found)){
						//No update needed
						updateMetadataFile.delete();
						return 1;
					}
					else if(!mcVersion.equals(this.updateCheckMCVersion)){
						//If its outdated, but not the same minecraft version, there is no update available.
						updateMetadataFile.delete();
						return 1;
					}
					else if(buildType != ' ' && (buildType !=BUILDTYPE && buildType !='r')) {
						//Wrong buildtype found in update file, do not honor update
						return 1;
					}
					else{
						modLogger.info("["+MODID+"] Update needed.");
						updateMetadataFile.delete();
						this.updateNeeded = true;
						return 2;
					}
				}
				else{
					updateMetadataFile.delete();
					return 0;
				}
			} catch (IOException e) {
				
				e.printStackTrace();
				updateMetadataFile.delete();
				return 0;
			}
			
		}
		else{
			//Return because the download must have failed.
			System.err.println("[WSBIM] Download for the update check metadata has failed");
			return 3;
		}
	}
	/**Extracts mod version information and sets a few variables in this class from that information
	 * 
	 *	@param metaFile The text file to search for information inside of.
	 * 	 @return Whether there was information found inside of the given file or not.
	 */
	 public boolean extractMetadataFileInformation(File metaFile) throws IOException{
		 
		

         BufferedReader bufferedreader = new BufferedReader(new FileReader(metaFile));
         String s = "";
         boolean includes_wsbim = false;
 		boolean includes_mc_version = false;
         while ((s = bufferedreader.readLine()) != null)
         {
             try{
            	 CharSequence charseq = "=";
            	 if(s.contains(charseq)){
            		String[] line = s.split("=");
            		//TODO Put all loads in here.
            		//Example:
            		/**
            		 * if(line[0].equals("TestBoolean")){this.testBoolean = Boolean.getBoolean(line[1]);}
            		 * 
            		 * 
            		 */

            		if(line[0].equals("wsbim_version")){
            			this.updateCheckVersion = line[1];
            			includes_wsbim = true;
            			modLogger.info("["+MODID+"] Found version " + line[1] + " in the update metadata file.");
            		}
            		if(line[0].equals("minecraft_version")){
            			this.updateCheckMCVersion = line[1];
            			includes_mc_version = true;
            		}
            		if(line[0].equals("new_update_url")){
            			//Desktop.getDesktop().browse(new URI(line[1]));
            			for(int i = 1; i < line.length; i++){
            				this.updateFileDownloadURL = s.substring("new_update_url".length() + 1);
            			}
            			
            		}
            		if(line[0].equals("mod_url")) {
            			for(int i = 1; i < line.length; i++){
            				this.modLink = s.substring("mod_url".length() + 1);
            			}
            		}
            	 	
            	 }
             }
             catch(Exception e){
            	 
             }
         }
         bufferedreader.close();
		 
         if(includes_wsbim && includes_mc_version){
 	 		return true;
 	 	}
		 return false;
	 }
	/**
	 * Compute the absolute file path to the jar file.
	 * The framework is based on http://stackoverflow.com/a/12733172/1614775
	 * But that gets it right for only one of the four cases.
	 * 
	 * @param aclass A class residing in the required jar.
	 * 
	 * @return A File object for the directory in which the jar file resides.
	 * During testing with NetBeans, the result is ./build/classes/,
	 * which is the directory containing what will be in the jar.
	 */
	public static File getJarDir(Class aclass) {
	    URL url;
	    String extURL;      //  url.toExternalForm();

	    // get an url
	    try {
	        url = aclass.getProtectionDomain().getCodeSource().getLocation();
	          // url is in one of two forms
	          //        ./build/classes/   NetBeans test
	          //        jardir/JarName.jar  froma jar
	    } catch (SecurityException ex) {
	        url = aclass.getResource(aclass.getSimpleName() + ".class");
	        // url is in one of two forms, both ending "/com/physpics/tools/ui/PropNode.class"
	        //          file:/U:/Fred/java/Tools/UI/build/classes
	        //          jar:file:/U:/Fred/java/Tools/UI/dist/UI.jar!
	    }

	    // convert to external form
	    extURL = url.toExternalForm();

	    // prune for various cases
	    if (extURL.endsWith(".jar"))   // from getCodeSource
	        extURL = extURL.substring(0, extURL.lastIndexOf("/"));
	    else {  // from getResource
	        String suffix = "/"+(aclass.getName()).replace(".", "/")+".class";
	        extURL = extURL.replace(suffix, "");
	        if (extURL.startsWith("jar:") && extURL.endsWith(".jar!"))
	            extURL = extURL.substring(4, extURL.lastIndexOf("/"));
	    }

	    // convert back to url
	    try {
	        url = new URL(extURL);
	    } catch (MalformedURLException mux) {
	        // leave url unchanged; probably does not happen
	    }

	    // convert url to File
	    try {
	        return new File(url.toURI());
	    } catch(URISyntaxException ex) {
	        return new File(url.getPath());
	    }
	}
}
