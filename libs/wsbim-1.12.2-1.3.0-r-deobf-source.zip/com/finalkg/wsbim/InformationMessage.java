package com.finalkg.wsbim;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class InformationMessage extends JDialog {

	private JPanel contentPanel = new JPanel();
	public JButton okButton;

	public static final String linee1 = "In this next dialog, the new version of wsbim";
	public static final String linee2 = "will be downloaded.";

	/**
	 * Create the dialog.
	 */
	public InformationMessage(String line1, String line2) {
		setModal(true);
		setTitle("WSBIM Update Checker");
		setAlwaysOnTop(true);
		setBounds(100, 100, 300, 120);
		final Toolkit toolkit = Toolkit.getDefaultToolkit();
		final Dimension screenSize = toolkit.getScreenSize();
		final int x = (screenSize.width - getWidth()) / 2;
		final int y = (screenSize.height - getHeight()) / 2;
		setLocation(x, y);
		contentPanel = new JPanel();
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JLabel lblTheNextWindow = new JLabel(line1);
			contentPanel.add(lblTheNextWindow);
		}
		{
			JLabel lblWsbimModFile = new JLabel(line2);
			contentPanel.add(lblWsbimModFile);
		}
		{
			JPanel buttonPane = new JPanel();
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("Continue");
				okButton.setActionCommand("");
				okButton.addActionListener(new ActionListener(){

					@Override
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
						
					}
					
				});
				getRootPane().setDefaultButton(okButton);
			}
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			buttonPane.add(okButton);
		}
	}
	
}
