package com.finalkg.wsbim.client.gui.screen;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.SwingWorker;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMUpdateChecker;
import com.finalkg.wsbim.client.gui.screen.notify.GuiWarningMessage;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class GuiUpdateFound extends GuiScreen{
	public GuiButton yesButton;
	public GuiButton noButton;
	public GuiButton openForums;
	private boolean shutdown;
	public GuiScreen nextGui;
	private final WSBIMUpdateChecker updateChecker;
	private final String line1;
	private final String line2;
	private final String line3;
	private GuiWarningMessage installWarning;
	private GuiWarningMessage linkWarning;
	/**
	 * 
	 * @param nextScreen - current screen.
	 * @param updateChecker - update checker instance
	 * @param line1text - Unlocalized name for line1 text
	 * @param line2text - unlocalized name for line2 text
	 * @param line3text - unlocalized name for line3 text
	 */
	public GuiUpdateFound(GuiScreen nextScreen, WSBIMUpdateChecker updateChecker, String line1text, String line2text, String line3text){
		this.nextGui = nextScreen;
		this.updateChecker = updateChecker;
		this.line1 = line1text;
		this.line2 = line2text;
		this.line3 = line3text;
	}
	
	public void drawScreen(int mx, int my, float part){
		this.drawDefaultBackground();
		super.drawScreen(mx, my, part);
		String line1 = I18n.format(this.line1, new Object[0])+" "+TextFormatting.GREEN+this.updateChecker.MOD_NAME+" (Version "+updateChecker.updateCheckMCVersion+"-"+updateChecker.updateCheckVersion+")";
		this.drawString(Minecraft.getMinecraft().fontRenderer, line1, this.width / 2 - (Minecraft.getMinecraft().fontRenderer.getStringWidth(line1) / 2), this.height / 2 - 80  - (Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT), 16777215);
		// (This will pause your game and bring you to the desktop)
		String line2 = I18n.format(this.line2, new Object[0]);
		this.drawString(Minecraft.getMinecraft().fontRenderer, line2, this.width / 2 - (Minecraft.getMinecraft().fontRenderer.getStringWidth(line2) / 2), this.height / 2  - 70 - (Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT), 16777215);
		String line3 = " "+I18n.format(this.line3, new Object[0]);
		this.drawString(Minecraft.getMinecraft().fontRenderer, line3, this.width / 2 - (Minecraft.getMinecraft().fontRenderer.getStringWidth(line3) / 2), this.height / 2  - 60 - (Minecraft.getMinecraft().fontRenderer.FONT_HEIGHT), 16777215);
		
		this.yesButton.x = this.width / 2 - (this.yesButton.width / 2);
		this.yesButton.y = this.height / 2 - 25;
		
		this.noButton.x = this.width / 2 - (this.noButton.width / 2);
		this.noButton.y = this.height / 2;
		
		this.openForums.x = this.width / 2 - (this.openForums.width / 2);
		this.openForums.y = this.height / 2 + 25;
		
		this.openForums.enabled = updateChecker.hasModForumsLink() && !updateChecker.getModForumsLink().equals("null");
		this.yesButton.enabled = updateChecker.updateFileDownloadURL != null && !updateChecker.updateFileDownloadURL.equals("null");
		this.installWarning.drawMessage(width, height, mx, my, part);
		this.linkWarning.drawMessage(width, height, mx, my, part);
	}
    /**
     * Called when the mouse is clicked. Args : mouseX, mouseY, clickedButton
     */
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException{
    	int result = this.installWarning.mouseClicked(mouseX, mouseY, mouseButton);
    	if(result == GuiWarningMessage.OK_OPTION) {
    		Minecraft.getMinecraft().displayGuiScreen(nextGui);
			try {
				org.lwjgl.opengl.Display.setFullscreen(false);
			} catch (org.lwjgl.LWJGLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			Minecraft.getMinecraft().setIngameNotInFocus();
			SwingWorker thread = new SwingWorker<Object, Object>(){

	    		@Override
	    		protected Object doInBackground() throws Exception {
	    			if(updateChecker.downloadUpdateThroughDesktop(false)){
	    				shutdown = true;
	    				Minecraft.getMinecraft().shutdown();
	    				
	    			}
	    			else{
	    				shutdown = false;
	    			}
	    			
					return null;
	    		}
			};
			thread.execute();
			return;
    	}
    	else if(result == GuiWarningMessage.CANCEL) {
    		this.installWarning.setVisible(false);
    		return;
    	}
    	else if(result == GuiWarningMessage.NONE) return;
    	int result2 = this.linkWarning.mouseClicked(mouseX, mouseY, mouseButton);
    	if(result2 == GuiWarningMessage.OK_OPTION) {
			try {
				Desktop.getDesktop().browse(new URI(updateChecker.getModForumsLink()));
			} catch (IOException | URISyntaxException e) {
				WSBIM.logger.warn("Unable to open mod forums link.");
				e.printStackTrace();
			}
			this.linkWarning.setVisible(false);
			return;
    	}
    	else if(result2 == GuiWarningMessage.CANCEL) {
    		this.linkWarning.setVisible(false);
    		return;
    	}
    	else if(result2 == GuiWarningMessage.NONE) return;
    	super.mouseClicked(mouseX, mouseY, mouseButton);
    }
	public void initGui(){
		super.initGui();
		this.yesButton = new GuiButton(0,0,0,TextFormatting.GREEN+I18n.format("gui.yes", new Object[0]));
		this.noButton = new GuiButton(1,0,20,TextFormatting.RED+I18n.format("gui.no", new Object[0]));
		this.openForums = new GuiButton(2,0,40,TextFormatting.GOLD+I18n.format("gui.wsbim.openForums", new Object[0]));
		boolean flag = this.installWarning != null ? this.installWarning.isVisible() : false;
		this.installWarning = new GuiWarningMessage(mc, false, true, 0, 150, "gui.wsbim.warning", "gui.wsbim.installWarning.line1", "\""+this.updateChecker.MOD_NAME+"\"", "gui.wsbim.installWarning.line2", this.updateChecker.MODID+"-"+this.updateChecker.updateCheckMCVersion+"-"+this.updateChecker.updateCheckVersion+".jar", "gui.wsbim.installWarning.line3", "gui.wsbim.setAllDefaults.line2");
		this.installWarning.setVisible(flag);
		boolean flag1 = this.linkWarning != null ? this.linkWarning.isVisible() : false;
		this.linkWarning = new GuiWarningMessage(mc, false, true, 0, 110, "gui.wsbim.warning", "gui.wsbim.linkWarning.line1", "gui.wsbim.setAllDefaults.line2");
		this.linkWarning.setVisible(flag1);
		this.buttonList.add(yesButton);
		this.buttonList.add(noButton);
		this.buttonList.add(openForums);
	}
	public void actionPerformed(GuiButton button){
		if(button.id == 0){
			this.installWarning.setVisible(true);
		}
		if(button.id == 1){
			Minecraft.getMinecraft().displayGuiScreen(nextGui);
			if(Minecraft.getMinecraft().player !=null)Minecraft.getMinecraft().player.sendMessage(new TextComponentString("["+updateChecker.MODID+"] Update was cancelled by user."));
		}
		if(button.id == 2) {
			this.linkWarning.setVisible(true);
		}
	}
}
