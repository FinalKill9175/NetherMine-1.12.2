package com.finalkg.wsbim.client.gui.screen.options;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions;
import com.finalkg.wsbim.client.gui.screen.notify.GuiWarningMessage;
import com.finalkg.wsbim.common.lib.IOptionsFile;
import com.finalkg.wsbim.common.options.WSBIMOptionFile;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLabel;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.text.TextFormatting;

public class GuiWSBIMOptions extends GuiScreen{
	private Minecraft mc;
	private GuiScreen prevScreen;
	private GuiWSBIMOptionsList optionsList;
	private GuiWarningMessage setAllDefaultsMessage;
	protected GuiWarningMessage linkMessage;
	protected GuiWarningMessage[] resetOptionsMessages;
	
	public GuiWSBIMOptions(Minecraft minecraft, GuiScreen prevScreen){
		this.mc = minecraft;
		this.prevScreen = prevScreen;
		this.resetOptionsMessages = new GuiWarningMessage[WSBIMOptions.OPTION_FILE_LIST.size()];
	}
    public void onGuiClosed() {
    	super.onGuiClosed();
    	try {
			WSBIM.optionsHandler.saveAllOptions();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    public void drawScreen(int x, int y, float renderTick){
    	 this.drawDefaultBackground();
    	 this.optionsList.drawScreen(x, y, renderTick);
    	 int k;
    	 for (k = 0; k < this.labelList.size(); ++k){
             ((GuiLabel)this.labelList.get(k)).drawLabel(this.mc, x, y);
         }
         for (k = 0; k < this.buttonList.size(); ++k){
             ((GuiButton)this.buttonList.get(k)).drawButton(this.mc, x, y, renderTick);
         }
         this.drawCenteredString(this.fontRenderer, I18n.format("gui.wsbim.options.title.main", new Object[0]), this.width / 2, 16, 16777215);
         this.setAllDefaultsMessage.drawMessage(this.width, this.height, x, y, renderTick);
         for(int i = 0; i < this.resetOptionsMessages.length; i++) {
        	 this.resetOptionsMessages[i].drawMessage(this.width, this.height, x, y, renderTick);
         }
         this.linkMessage.drawMessage(width, height, x, y, renderTick);
    }

	public void initGui(){
		this.optionsList = new GuiWSBIMOptionsList(this, this.mc);
		for(int i = 0; i < this.resetOptionsMessages.length; i++) {
			boolean stillVisible = this.resetOptionsMessages[i] != null ? this.resetOptionsMessages[i].isVisible() : false;
			this.resetOptionsMessages[i] = new GuiWarningMessage(mc, false, true, 0, 115, "gui.wsbim.warning", "gui.wsbim.reset.warning.line1", "\""+WSBIMOptions.OPTION_FILE_LIST.get(i).getModName()+"\"", "gui.wsbim.reset.warning.line2");
			this.resetOptionsMessages[i].setVisible(stillVisible);
		}
		boolean stillVisible = this.setAllDefaultsMessage != null ? this.setAllDefaultsMessage.isVisible() : false;
		this.setAllDefaultsMessage = new GuiWarningMessage(this.mc, true, true, 0, 110, "gui.wsbim.majorWarning", "gui.wsbim.setAllDefaults.line1", "gui.wsbim.setAllDefaults.line2");
		this.setAllDefaultsMessage.setVisible(stillVisible);
        boolean stillVisible2 = this.linkMessage != null ? this.linkMessage.isVisible() : false;
        this.linkMessage = new GuiWarningMessage(this.mc, false, true, 0, 110, "gui.wsbim.warning", "gui.wsbim.linkWarning.line1", "gui.wsbim.setAllDefaults.line2");
        this.linkMessage.setVisible(stillVisible2);
        this.buttonList.add(new GuiButton(200, this.width / 2 - 155 + 110, this.height - 29, 100, 20, I18n.format("gui.done")));
        this.buttonList.add(new GuiButton(201, this.width / 2 - 155, this.height - 29, 100, 20, TextFormatting.RED+I18n.format("gui.wsbim.options.setAllDefaults", new Object[0])));
        this.buttonList.add(new GuiButton(202, this.width / 2 - 155 + 220, this.height - 29, 100, 20, TextFormatting.AQUA+I18n.format("gui.wsbim.options.openConfigFolder", new Object[0])));
	}
    public void handleMouseInput() throws IOException{
        super.handleMouseInput();
        this.optionsList.handleMouseInput();
    }
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException{
    	boolean flag = false;
    	for(int i = 0; i < this.resetOptionsMessages.length; i++) {
    		int result = this.resetOptionsMessages[i].mouseClicked(mouseX, mouseY, mouseButton);
    		if(result == GuiWarningMessage.OK_OPTION) {
    			WSBIMOptions.OPTION_FILE_LIST.get(i).setDefaultOptions();
    			this.resetOptionsMessages[i].setVisible(false);
    			flag = true;
    		}
    		else if(result == GuiWarningMessage.CANCEL) {
    			this.resetOptionsMessages[i].setVisible(false);
    			flag = true;
    		}
    		else if(result == GuiWarningMessage.NONE) flag = true;
    	}
    	if(flag) return;
    	int result = this.setAllDefaultsMessage.mouseClicked(mouseX, mouseY, mouseButton);
    	if(result == GuiWarningMessage.OK_OPTION) {
			WSBIM.optionsHandler.setDefaults();
			for(IOptionsFile optionFile : WSBIMOptions.OPTION_FILE_LIST) optionFile.setDefaultOptions();
			this.setAllDefaultsMessage.setVisible(false);
			mc.displayGuiScreen(this);
			return;
    	}
    	else if(result == GuiWarningMessage.CANCEL) {
    		this.setAllDefaultsMessage.setVisible(false);
    		return;
    	}
    	else if(result == GuiWarningMessage.NONE) return;
    	int result2 = this.linkMessage.mouseClicked(mouseX, mouseY, mouseButton);
    	if(result2 == GuiWarningMessage.OK_OPTION) {
    		try {
				Desktop.getDesktop().browse(new URI(WSBIM.MOD_DEPENDENTS_LIST_URI));
			} catch (URISyntaxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		this.linkMessage.setVisible(false);
    		return;
    	}
    	else if (result2 == GuiWarningMessage.CANCEL) {
    		this.linkMessage.setVisible(false);
    		return;
    	}
    	else if(result2 == GuiWarningMessage.NONE) return;
        if(mouseButton != 0 || !this.optionsList.mouseClicked(mouseX, mouseY, mouseButton)){
            super.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }
    /**
     * Called when a mouse button is released.
     */
    protected void mouseReleased(int mouseX, int mouseY, int state){
        if(state != 0 || !this.optionsList.mouseReleased(mouseX, mouseY, state)){
            super.mouseReleased(mouseX, mouseY, state);
        }
    }

	public void actionPerformed(GuiButton b){
		if(b.id == 200){
			this.openPrevGui(mc);
		}
		if(b.id == 201){
			this.setAllDefaultsMessage.setVisible(true);
		}
		if(b.id == 202) {
        	try {
				Desktop.getDesktop().open(WSBIMOptionFile.wsbimFolder);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void openPrevGui(Minecraft mc){
		mc.displayGuiScreen(prevScreen);
	}
}
