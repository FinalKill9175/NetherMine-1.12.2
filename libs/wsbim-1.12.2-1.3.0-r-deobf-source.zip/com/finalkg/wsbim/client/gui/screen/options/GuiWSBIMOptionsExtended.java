package com.finalkg.wsbim.client.gui.screen.options;

import java.io.IOException;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.gui.screen.notify.GuiWarningMessage;
import com.finalkg.wsbim.client.gui.screen.options.GuiWSBIMOptionsExtendedList.OptionButtonEntry;
import com.finalkg.wsbim.client.lib.Position;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.client.lib.option.OptionFloat;
import com.finalkg.wsbim.client.lib.option.OptionInteger;
import com.finalkg.wsbim.common.lib.ColorHelper;
import com.finalkg.wsbim.common.lib.IOptionsFile;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLabel;
import net.minecraft.client.gui.GuiListExtended;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;

public class GuiWSBIMOptionsExtended extends GuiScreen{
	private Minecraft mc;
	private OptionCategory[] categories;
	private String unlocalizedTitle;
	protected IOptionsFile optionsFile;
	private GuiWSBIMOptionsExtendedList optionsList;
	private final boolean first;
	private final int entryListHeight;
	protected GuiWarningMessage serverSideWarning;
	
	/**
	 * For use with a new OptionGui
	 * @param file -IOptionsFile
	 * @param minecraft - Minecraft.getMinecraft()
	 * @param titleUnlocalizedName - Translation Key for title
	 * @param firstGUI - is this the first gui in the options?
	 * @param categories - OptionCategories
	 */
	public GuiWSBIMOptionsExtended(IOptionsFile file, Minecraft minecraft, String titleUnlocalizedName, boolean firstGUI, OptionCategory... categories){
		this.mc = minecraft;
		this.categories = categories;
		this.unlocalizedTitle = titleUnlocalizedName;
		this.optionsFile = file;
		this.first = firstGUI;
		this.entryListHeight = 20;
	}
	public GuiWSBIMOptionsExtended(IOptionsFile file, Minecraft minecraft, String titleUnlocalizedName, boolean firstGUI, int entryListHeight, OptionCategory... categories){
		this.mc = minecraft;
		this.categories = categories;
		this.unlocalizedTitle = titleUnlocalizedName;
		this.optionsFile = file;
		this.first = firstGUI;
		this.entryListHeight = entryListHeight;
	}
    public void onGuiClosed() {
    	super.onGuiClosed();
    	try {
			WSBIM.optionsHandler.saveOptionsForOptionsFile(optionsFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    public void drawScreen(int x, int y, float renderTick){
    	 this.drawDefaultBackground();
    	 this.optionsList.drawScreen(x, y, renderTick);
         String renderString = this.optionsFile.getModID()+"-"+this.optionsFile.getModVersion();
         int length = this.fontRenderer.getStringWidth(renderString);
         this.drawCenteredString(fontRenderer, renderString, this.width - (length / 2), this.height - fontRenderer.FONT_HEIGHT, ColorHelper.convertRGBToInteger(255/2, 255/2, 255/2));
    	 int k;
    	 for (k = 0; k < this.labelList.size(); ++k){
             ((GuiLabel)this.labelList.get(k)).drawLabel(this.mc, x, y);
         }
         for (k = 0; k < this.buttonList.size(); ++k){
             ((GuiButton)this.buttonList.get(k)).drawButton(this.mc, x, y, renderTick);
         }
         for(k = 0; k < this.optionsList.getSize(); k++) {
        	 if(this.optionsList.getListEntry(k) !=null) {
        		 if(this.optionsList.getListEntry(k) instanceof GuiWSBIMOptionsExtendedList.OptionButtonEntry) {
        			 GuiWSBIMOptionsExtendedList.OptionButtonEntry buttonEntry = (OptionButtonEntry) this.optionsList.getListEntry(k);
        			 if(buttonEntry.optionButton != null && this.optionsList.isMouseYWithinSlotBounds(y)) {
        				 GuiButton optionButton = buttonEntry.optionButton;
        	        	 if(optionButton instanceof GuiButtonOption) ((GuiButtonOption)optionButton).drawDescription(mc, x, y);
        	        	 if(optionButton instanceof GuiSliderOptionFloat) ((GuiSliderOptionFloat)optionButton).drawDescription(mc, x, y);
        	        	 if(optionButton instanceof GuiSliderOptionInteger) ((GuiSliderOptionInteger)optionButton).drawDescription(mc, x, y);
        			 }
        		 }
        	 }
         }
         this.drawCenteredString(this.fontRenderer, I18n.format(this.unlocalizedTitle, new Object[0]), this.width / 2, 16, 16777215);
         this.serverSideWarning.drawMessage(this.width, this.height, x, y, renderTick);
    }
    public void handleMouseInput() throws IOException{
        super.handleMouseInput();
        this.optionsList.handleMouseInput();
    }
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException{
    	int result = this.serverSideWarning.mouseClicked(mouseX, mouseY, mouseButton);
    	if(result == GuiWarningMessage.OK_OPTION) {
    		this.openPrevGui(mc);
    		return;
    	}
    	else if(result == GuiWarningMessage.NONE){return;}
        if(mouseButton != 0 || !this.optionsList.mouseClicked(mouseX, mouseY, mouseButton)){
            super.mouseClicked(mouseX, mouseY, mouseButton);
        }
    }
    /**
     * Called when a mouse button is released.
     */
    protected void mouseReleased(int mouseX, int mouseY, int state){
        if(state != 0 || !this.optionsList.mouseReleased(mouseX, mouseY, state)){
            super.mouseReleased(mouseX, mouseY, state);
        }
    }

	public void initGui(){
		this.optionsList = new GuiWSBIMOptionsExtendedList(this, mc, this.categories, this.entryListHeight);
		boolean stillVisible = this.serverSideWarning !=null? this.serverSideWarning.isVisible() : false;
		this.serverSideWarning = new GuiWarningMessage(mc, false, false, 0, 120, "gui.wsbim.warning", "gui.wsbim.serversideoption.line1", "gui.wsbim.serversideoption.line2", "gui.wsbim.serversideoption.line3", "gui.wsbim.serversideoption.line4", "gui.wsbim.serversideoption.line5");
		this.serverSideWarning.setVisible(stillVisible);
		this.buttonList.add(new GuiButton(200, this.width / 2 - 100, this.height  - 29, I18n.format("gui.done", new Object[0])));
	}
	
	public void actionPerformed(GuiButton b){
		if(b.id == 200){
			if(this.optionsList.warnUser) {
				this.serverSideWarning.setVisible(true);
				this.buttonList.get(0).enabled = false;
			}
			else this.openPrevGui(mc);
		}
	}
	
	public void openPrevGui(Minecraft mc){
		mc.displayGuiScreen(this.first ? new GuiWSBIMOptions(mc, null) : this.optionsFile.getMainGUI().getGuiToOpen());
	}

    protected void keyTyped(char typedChar, int keyCode) throws IOException{
        if (keyCode == 1){
            this.openPrevGui(mc);

            if (this.mc.currentScreen == null)
            {
                this.mc.setIngameFocus();
            }
        }
    }
}
