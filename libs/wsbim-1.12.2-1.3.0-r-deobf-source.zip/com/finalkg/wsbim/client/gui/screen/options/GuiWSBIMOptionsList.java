package com.finalkg.wsbim.client.gui.screen.options;

import java.awt.Desktop;
import java.io.IOException;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions;
import com.finalkg.wsbim.client.gui.screen.notify.GuiWarningMessage;
import com.finalkg.wsbim.common.lib.ColorHelper;
import com.finalkg.wsbim.common.lib.IOptionsFile;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiKeyBindingList;
import net.minecraft.client.gui.GuiListExtended;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GuiWSBIMOptionsList extends GuiListExtended {

	protected final GuiWSBIMOptions optionsGui;
	private final Minecraft mc;
	private final GuiListExtended.IGuiListEntry[] listEntries;
	private int maxListLabelWidth;
	
	public GuiWSBIMOptionsList(GuiWSBIMOptions options, Minecraft mcIn) {
		super(mcIn, options.width + 45, options.height, 32, options.height - 32, 20);
		this.optionsGui = options;
		this.mc = mcIn;
		this.listEntries = new GuiListExtended.IGuiListEntry[WSBIMOptions.OPTION_FILE_LIST.size() * 2 + 2];
		int i = 0;
		for(IOptionsFile optionsFile : WSBIMOptions.OPTION_FILE_LIST) {
			int j = mcIn.fontRenderer.getStringWidth(optionsFile.getModName());
			if(j > this.maxListLabelWidth) this.maxListLabelWidth = j;
			this.listEntries[i++] = new OptionFileTitleEntry(optionsFile.getModName());
			this.listEntries[i++] = new OptionFileButtonsEntry(optionsFile);
		}
		this.listEntries[i++] = new OptionFileTitleEntry("");
		this.listEntries[i++] = new FindMoreModsEntry();
	}

	@Override
	public int getListWidth(){
        return super.getListWidth();
    }
	@Override
    protected int getScrollBarX(){
        return super.getScrollBarX();
    }
	@Override
	public IGuiListEntry getListEntry(int index) {
		return this.listEntries[index];
	}

	@Override
	protected int getSize() {
		return this.listEntries.length;
	}

	@SideOnly(Side.CLIENT)
    public class OptionFileTitleEntry implements GuiListExtended.IGuiListEntry
    {
        private final String keyDesc;

        private OptionFileTitleEntry(String desc){
            this.keyDesc = desc;
        }

        public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected, float partialTicks)
        {
        	GuiWSBIMOptionsList.this.optionsGui.drawCenteredString(GuiWSBIMOptionsList.this.mc.fontRenderer, this.keyDesc, GuiWSBIMOptionsList.this.optionsGui.width / 2, y + slotHeight / 2, ColorHelper.WHITE);
        }

        /**
         * Called when the mouse is clicked within this entry. Returning true means that something within this entry was
         * clicked and the list should not be dragged.
         */
        public boolean mousePressed(int slotIndex, int mouseX, int mouseY, int mouseEvent, int relativeX, int relativeY){
        	return false;
        }

        /**
         * Fired when the mouse button is released. Arguments: index, x, y, mouseEvent, relativeX, relativeY
         */
        public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY)
        {
        }

        public void updatePosition(int slotIndex, int x, int y, float partialTicks)
        {
        }
    }
    @SideOnly(Side.CLIENT)
    public class OptionFileButtonsEntry implements GuiListExtended.IGuiListEntry
    {
        /** The keybinding specified for this KeyEntry */
        private final IOptionsFile optionFile;
        private final GuiButton btnViewOptions;
        private final GuiButton btnReset;

        private OptionFileButtonsEntry(IOptionsFile file){
            this.optionFile = file;
            this.btnViewOptions = new GuiButton(0, 0, 0, 130, 20, I18n.format("gui.wsbim.button.viewOptions"));
            this.btnViewOptions.enabled = this.optionFile.getMainGUI() != null;
            this.btnReset = new GuiButton(0, 0, 0, 75, 20, TextFormatting.RED+I18n.format("controls.reset"));
        }

        public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected, float partialTicks)
        {
        	this.btnReset.x = GuiWSBIMOptionsList.this.optionsGui.width / 2 + 30;
            this.btnReset.y = y;
            this.btnReset.drawButton(GuiWSBIMOptionsList.this.mc, mouseX, mouseY, partialTicks);
            this.btnViewOptions.x = GuiWSBIMOptionsList.this.optionsGui.width / 2 - 105;
            this.btnViewOptions.y = y;
            this.btnViewOptions.drawButton(mc, mouseX, mouseY, partialTicks);
            this.btnReset.drawButton(GuiWSBIMOptionsList.this.mc, mouseX, mouseY, partialTicks);
        }

        /**
         * Called when the mouse is clicked within this entry. Returning true means that something within this entry was
         * clicked and the list should not be dragged.
         */
        public boolean mousePressed(int slotIndex, int mouseX, int mouseY, int mouseEvent, int relativeX, int relativeY){
            if (this.btnViewOptions.mousePressed(GuiWSBIMOptionsList.this.mc, mouseX, mouseY)){
            	GuiWSBIMOptionsList.this.mc.displayGuiScreen(this.optionFile.getMainGUI().getGuiToOpen());
            	this.btnViewOptions.playPressSound(GuiWSBIMOptionsList.this.mc.getSoundHandler());
                return true;
            }
            else if (this.btnReset.mousePressed(GuiWSBIMOptionsList.this.mc, mouseX, mouseY)){
            	for(int i = 0; i < WSBIMOptions.OPTION_FILE_LIST.size(); i++) {
            		if(WSBIMOptions.OPTION_FILE_LIST.get(i).getModID().equals(this.optionFile.getModID())) {
            			GuiWSBIMOptionsList.this.optionsGui.resetOptionsMessages[i].setVisible(true);
            			this.btnReset.playPressSound(GuiWSBIMOptionsList.this.mc.getSoundHandler());
            		}
            	}
                return true;
            }
            else
            {
                return false;
            }
        }

        /**
         * Fired when the mouse button is released. Arguments: index, x, y, mouseEvent, relativeX, relativeY
         */
        public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY)
        {
            this.btnViewOptions.mouseReleased(relativeX, relativeY);
            this.btnReset.mouseReleased(relativeX, relativeY);
        }

        public void updatePosition(int slotIndex, int x, int y, float partialTicks)
        {
        }
    }
    @SideOnly(Side.CLIENT)
    public class FindMoreModsEntry implements GuiListExtended.IGuiListEntry
    {
        /** The keybinding specified for this KeyEntry */
        private final GuiButton findMoreMods;

        private FindMoreModsEntry(){
            this.findMoreMods = new GuiButton(0, 0, 0, 160, 20, TextFormatting.GOLD+I18n.format("gui.wsbim.button.findMoreMods"));

        }

        public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected, float partialTicks)
        {
        	this.findMoreMods.enabled = WSBIM.MOD_DEPENDENTS_LIST_URI != null;
        	this.findMoreMods.x = GuiWSBIMOptionsList.this.optionsGui.width / 2 - 80;
            this.findMoreMods.y = y;
            this.findMoreMods.drawButton(GuiWSBIMOptionsList.this.mc, mouseX, mouseY, partialTicks);
        }

        /**
         * Called when the mouse is clicked within this entry. Returning true means that something within this entry was
         * clicked and the list should not be dragged.
         */
        public boolean mousePressed(int slotIndex, int mouseX, int mouseY, int mouseEvent, int relativeX, int relativeY){
            if (this.findMoreMods.mousePressed(GuiWSBIMOptionsList.this.mc, mouseX, mouseY)){
            	GuiWSBIMOptionsList.this.optionsGui.linkMessage.setVisible(true);
            	this.findMoreMods.playPressSound(GuiWSBIMOptionsList.this.mc.getSoundHandler());
                return true;
            }
            else
            {
                return false;
            }
        }

        /**
         * Fired when the mouse button is released. Arguments: index, x, y, mouseEvent, relativeX, relativeY
         */
        public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY)
        {
            this.findMoreMods.mouseReleased(relativeX, relativeY);
        }

        public void updatePosition(int slotIndex, int x, int y, float partialTicks)
        {
        	
        }
    }
}
