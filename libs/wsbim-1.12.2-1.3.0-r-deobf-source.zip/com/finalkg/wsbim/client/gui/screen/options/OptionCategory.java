package com.finalkg.wsbim.client.gui.screen.options;

import java.util.ArrayList;
import java.util.List;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.common.lib.IOptionsFile;

import net.minecraft.client.resources.I18n;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class OptionCategory {
	
	private final String unlocalizedTitle;
	private final String localizedTitle;
	private final Option[] options;

	/**
	 * USE getMainGUI method if you only want ONE sub menu with categories for your options
	 * and IGNORE the registerCustomOptions method. Return A NEW OptionGUI(new GuiWSBIMOptionsExtended()) 
	 * with all of your option categories
	 * @param unlocalizedTitle
	 * @param options
	 */
	public OptionCategory(String unlocalizedTitle, Option...options) {
		this.unlocalizedTitle = unlocalizedTitle;
		this.localizedTitle = unlocalizedTitle !=null ? I18n.format(unlocalizedTitle, new Object[0]) : null;
		this.options = options;
	}
	/**
	 * THIS CONSTRUCTOR is marked for removal with next MC version. Still here for legacy support.
	 * DO NOT USE THIS
	 */
	@Deprecated
	public OptionCategory(String unlocalizedTitle, IOptionsFile optionsFile, int start_index, int end_index) {
		this.unlocalizedTitle = unlocalizedTitle;
		this.localizedTitle = unlocalizedTitle !=null ? I18n.format(unlocalizedTitle, new Object[0]) : null;
		List<Option> optionList = WSBIM.optionsHandler.getOptionList(optionsFile.getModID());
		List<Option> dummyList = new ArrayList<Option>();
		int k = 0;
		for(int i = start_index; i < end_index; i++) {
			if(optionList.get(i) != null) {
				dummyList.add(optionList.get(i));
				k++;
			}
		}
		options = new Option[k];
		for(int j = 0; j < k; j++) {
			options[j] = dummyList.get(j);
		}
	}
	/**Marked for removal next MC Version. DO NOT USE*/
	@Deprecated
	public OptionCategory(String unlocalizedTitle, List<Option> optionList, int start_index, int end_index) {
		this.unlocalizedTitle = unlocalizedTitle;
		this.localizedTitle = unlocalizedTitle !=null ? I18n.format(unlocalizedTitle, new Object[0]) : null;
		List<Option> dummyList = new ArrayList<Option>();
		int k = 0;
		for(int i = start_index; i < end_index; i++) {
			if(optionList.get(i) != null) {
				dummyList.add(optionList.get(i));
				k++;
			}
		}
		options = new Option[k];
		for(int j = 0; j < k; j++) {
			options[j] = dummyList.get(j);
		}
	}
	/**
	 * Gets the title for this category.
	 * @return
	 */
	public String getCategoryTitle() {
		return this.unlocalizedTitle == null? null : this.localizedTitle;
	}
	/**
	 * Does this category have a title
	 * @return
	 */
	public boolean hasTitle() { return this.getCategoryTitle() !=null;}
	
	public int getCategorySize() {
		return this.options.length;
	}
	
	public Option getOption(int index) { return this.options[index]; }
}
