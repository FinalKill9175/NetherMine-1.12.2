package com.finalkg.wsbim.client.gui.screen;

import org.lwjgl.opengl.GL11;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.client.lib.GuiHelper;
import com.finalkg.wsbim.common.lib.ColorHelper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;

public class GuiButtonCustom extends GuiButton{

	public GuiButtonCustom(int id, int x, int y,
			int width, int height, String p_i1021_6_) {
		super(id, x, y, width, height, p_i1021_6_);
		// TODO Auto-generated constructor stub
	}
	/**
     * Draws this button to the screen.
     */
    public void drawButton(Minecraft mc, int mouseX, int mouseY, float renderTick){
        if (this.visible){
            FontRenderer fontrenderer = mc.fontRenderer;
            this.hovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
            int k = this.getHoverState(this.hovered);
            GL11.glEnable(GL11.GL_BLEND);
            int[] text_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.textColor);
        	int[] foreground_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.foregroundColor);
        	int[] background_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.backgroundColor);
        	int l = 14737632;
            float alpha = WSBIM.options.defaultBackgroundOpacity;
            if (packedFGColour != 0){
                l = packedFGColour;
            }
            else if (!this.enabled){
                l = 10526880;
                alpha = 0.2F;
            }
            else if (this.hovered){
                l = 16777120;
                alpha = WSBIM.options.defaultForegroundOpacity;
            }
            int j = ColorHelper.convertRGBToInteger(text_rgb[0], text_rgb[1], text_rgb[2]);
            if (!this.enabled)
            {
                j = ColorHelper.BLACK;
            }
            GuiHelper.drawSpecificRect(x, y, x+width, y+height, this.hovered ? (foreground_rgb[0] / 255F) : (background_rgb[0] / 255F), this.hovered ? (foreground_rgb[1] / 255F) : (background_rgb[1] / 255F), this.hovered ? (foreground_rgb[2] / 255F) : (background_rgb[2] / 255F), alpha);
            this.mouseDragged(mc, mouseX, mouseY);
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow(this.displayString, this.x + width/2 - (Minecraft.getMinecraft().fontRenderer.getStringWidth(this.displayString) / 2), this.y + (this.height - 8) / 2, j);
        }
    }
}
