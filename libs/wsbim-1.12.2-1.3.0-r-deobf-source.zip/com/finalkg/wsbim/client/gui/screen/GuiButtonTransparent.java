package com.finalkg.wsbim.client.gui.screen;

import java.awt.Color;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.client.lib.GuiHelper;
import com.finalkg.wsbim.common.lib.ColorHelper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;

public class GuiButtonTransparent extends GuiButton{

	public GuiButtonTransparent(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
		super(buttonId, x, y, widthIn, heightIn, buttonText);
	}
    /**
     * Draws this button to the screen.
     */
    public void drawButton(Minecraft mc, int mouseX, int mouseY, float partialTicks){
        if (this.visible){
            FontRenderer fontrenderer = mc.fontRenderer;
            this.hovered = mouseX >= this.x && mouseY >= this.y && mouseX < this.x + this.width && mouseY < this.y + this.height;
            int i = this.getHoverState(this.hovered);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
            int[] foreground_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.foregroundColor);
            int[] background_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.backgroundColor);
        	boolean highlight = this.hovered && this.enabled;
        	float alpha = WSBIM.options.defaultBackgroundOpacity;
        	if (!this.enabled){
                alpha = 0.2F;
            }
            else if (this.hovered){
                alpha = WSBIM.options.defaultForegroundOpacity;
            }
        	boolean flag = false;
        	flag = this.displayString.equals("LANG");
        	if(!flag) GuiHelper.drawSpecificRect(x, y, x + width, y + height, highlight ? (foreground_rgb[0] / 255F) : (background_rgb[0] / 255F), highlight ? (foreground_rgb[1] / 255F) : (background_rgb[1] / 255F), highlight ? (foreground_rgb[2] / 255F) : (background_rgb[2] / 255F), alpha);
        	else {
        		int k = 106;
        		if (this.hovered){
                    k += this.height;
                }
        		mc.renderEngine.bindTexture(BUTTON_TEXTURES);
        		GlStateManager.color(1F, 1F, 1F);
                this.drawTexturedModalRect(this.x, this.y, 0, k, this.width, this.height);
        	}
            this.mouseDragged(mc, mouseX, mouseY);
            int j = ColorHelper.convertRGBToInteger(ColorHelper.convertHexStringToRGB(WSBIM.options.textColor));
            if (!this.enabled)
            {
                j = ColorHelper.BLACK;
            }

            if(!flag) this.drawCenteredString(fontrenderer, this.displayString, this.x + this.width / 2, this.y + (this.height - 8) / 2, j);
        }
    }
}
