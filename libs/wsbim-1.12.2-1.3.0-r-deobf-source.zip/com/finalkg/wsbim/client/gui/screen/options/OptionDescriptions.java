package com.finalkg.wsbim.client.gui.screen.options;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.finalkg.wsbim.client.lib.option.Option;
import com.google.common.collect.Maps;

public class OptionDescriptions {
	public static final Map<String, String[]> DESCRIPTIONS_MAP = Maps.<String, String[]>newHashMap();
	
	public static List<String> getItemDescription(String valName){
		if(valName.equals("")) return null;
		if(DESCRIPTIONS_MAP.containsKey(valName)) {
			return getStringListFromArray(DESCRIPTIONS_MAP.get(valName));
		}
		return null;
	}
		
	public static List<String> getStringListFromArray(String... desc){
		List<String> strs = new ArrayList<String>();
		for(int i = 0; i < desc.length; i++){
			strs.add(desc[i]);
		}
		
		return strs;
	}
}
