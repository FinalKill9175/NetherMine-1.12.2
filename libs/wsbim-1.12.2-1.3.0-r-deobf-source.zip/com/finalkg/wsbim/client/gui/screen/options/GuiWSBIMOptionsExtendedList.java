package com.finalkg.wsbim.client.gui.screen.options;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.client.lib.option.OptionFloat;
import com.finalkg.wsbim.client.lib.option.OptionInteger;
import com.finalkg.wsbim.common.lib.ColorHelper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiListExtended;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiWSBIMOptionsExtendedList extends GuiListExtended {
	
	private GuiWSBIMOptionsExtended optionsGui;
	private final Minecraft mc;
	private final GuiListExtended.IGuiListEntry[] listEntries;
	protected boolean warnUser = false;
	
	protected GuiWSBIMOptionsExtendedList(GuiWSBIMOptionsExtended options, Minecraft mcIn, OptionCategory[] categories, int slotHeight) {
		super(mcIn, options.width + 45, options.height, 32, options.height - 32, slotHeight);
		this.optionsGui = options;
		this.mc = mcIn;
		int num_of_options = 0;
		for(int i = 0; i < categories.length; i++) {
			if(categories[i] != null) {
				num_of_options +=categories[i].getCategorySize();
			}
		}
		int num_of_titles = 0;
		for(int i = 0; i < categories.length; i++) {
			if(categories[i] !=null) {
				if(categories[i].hasTitle() && categories[i].getCategoryTitle() != null && !categories[i].getCategoryTitle().isEmpty()) num_of_titles++;
			}
		}
		this.listEntries = new GuiListExtended.IGuiListEntry[num_of_titles + num_of_options];
		int start = 0;
		for(int i = 0; i < categories.length; i++) {
			OptionCategory cat = categories[i];
			if(cat !=null) {
				boolean hasTitle = cat.hasTitle() && cat.getCategoryTitle() != null && !cat.getCategoryTitle().isEmpty();
				if(hasTitle) {
					this.listEntries[start] = new GuiWSBIMOptionsExtendedList.TitleEntry(cat.getCategoryTitle());
					start ++;
				}
				int add = 0;
				for(int k = 0; k < cat.getCategorySize(); k++) {
					Option option = cat.getOption(k);
					if(option != null){
						if((option.type !=OptionType.INT) && (option.type !=OptionType.FLOAT) && (option.type != OptionType.STRING) && (option.type !=OptionType.GUI)){
							this.listEntries[start+add] = new GuiWSBIMOptionsExtendedList.OptionButtonEntry(new GuiButtonOption(option, 0, 0, 0, 250, 20, option.guiName, optionsGui.optionsFile), option);
						}
						else if(option.type == OptionType.GUI){
							this.listEntries[start+add] = new GuiWSBIMOptionsExtendedList.OptionButtonEntry(new GuiButtonOpenGUI(option, 0, 0, 0, 250, 20, option.guiName), option);
						}
						else if(option.type == OptionType.INT){
							this.listEntries[start+add] = new GuiWSBIMOptionsExtendedList.OptionButtonEntry(new GuiSliderOptionInteger(0, 0, 0, 250, 20, (OptionInteger) option), option);
						}
						else if(option.type == OptionType.FLOAT){
							this.listEntries[start+add] = new GuiWSBIMOptionsExtendedList.OptionButtonEntry(new GuiSliderOptionFloat(-1, 0, 0, 250, 20, (OptionFloat)option), option);
						}
					}
					add ++;
				}
				start +=add;
			}
		}
	}
	@Override
	public int getListWidth(){
        return super.getListWidth() + 40;
    }
	@Override
    protected int getScrollBarX(){
        return super.getScrollBarX();
    }
	@Override
	public IGuiListEntry getListEntry(int index) {
		return this.listEntries[index];
	}

	@Override
	protected int getSize() {
		return this.listEntries.length;
	}
	@SideOnly(Side.CLIENT)
    public class OptionButtonEntry implements GuiListExtended.IGuiListEntry
    {
        protected final GuiButton optionButton;
        protected final Option option;

        public OptionButtonEntry(GuiButton optionButton, Option option){
            this.optionButton = optionButton;
            this.option = option;
        }

        public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected, float partialTicks){
        	this.optionButton.x = x - 20;
        	this.optionButton.y = y;
   		 	this.optionButton.drawButton(mc, mouseX, mouseY, partialTicks);
        }

        /**
         * Called when the mouse is clicked within this entry. Returning true means that something within this entry was
         * clicked and the list should not be dragged.
         */
        public boolean mousePressed(int slotIndex, int mouseX, int mouseY, int mouseEvent, int relativeX, int relativeY)
        {
        	if(this.optionButton.mousePressed(mc, mouseX, mouseY)) {
        		if(!this.option.clientSided) GuiWSBIMOptionsExtendedList.this.warnUser = true; // Warn user when changing these options.
        		this.optionButton.playPressSound(GuiWSBIMOptionsExtendedList.this.mc.getSoundHandler());
        		return true;
        	}
            return false;
        }

        /**
         * Fired when the mouse button is released. Arguments: index, x, y, mouseEvent, relativeX, relativeY
         */
        public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY)
        {
        	this.optionButton.mouseReleased(relativeX, relativeY);
        }

        public void updatePosition(int slotIndex, int x, int y, float partialTicks)
        {
        }
    }
	@SideOnly(Side.CLIENT)
    public class TitleEntry implements GuiListExtended.IGuiListEntry{
        private final String labelText;
        private final int labelWidth;

        public TitleEntry(String name){
            this.labelText = name;
            this.labelWidth = GuiWSBIMOptionsExtendedList.this.mc.fontRenderer.getStringWidth(this.labelText);
        }
        public void drawEntry(int slotIndex, int x, int y, int listWidth, int slotHeight, int mouseX, int mouseY, boolean isSelected, float partialTicks){
        	GuiWSBIMOptionsExtendedList.this.mc.fontRenderer.drawString(this.labelText, GuiWSBIMOptionsExtendedList.this.mc.currentScreen.width / 2 - this.labelWidth / 2, y + slotHeight - GuiWSBIMOptionsExtendedList.this.mc.fontRenderer.FONT_HEIGHT - 1, ColorHelper.WHITE);
        }
        /**
         * Called when the mouse is clicked within this entry. Returning true means that something within this entry was
         * clicked and the list should not be dragged.
         */
        public boolean mousePressed(int slotIndex, int mouseX, int mouseY, int mouseEvent, int relativeX, int relativeY){
            return false;
        }
        /**
         * Fired when the mouse button is released. Arguments: index, x, y, mouseEvent, relativeX, relativeY
         */
        public void mouseReleased(int slotIndex, int x, int y, int mouseEvent, int relativeX, int relativeY){}
        public void updatePosition(int slotIndex, int x, int y, float partialTicks){}
    }
}
