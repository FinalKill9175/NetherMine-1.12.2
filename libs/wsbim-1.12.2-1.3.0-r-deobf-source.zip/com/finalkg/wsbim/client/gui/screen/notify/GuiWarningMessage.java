package com.finalkg.wsbim.client.gui.screen.notify;

import java.io.IOException;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.client.lib.GuiHelper;
import com.finalkg.wsbim.common.lib.ColorHelper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.TextFormatting;

public class GuiWarningMessage extends Gui {
	
	private final boolean isMajor;
	private final boolean isConfirmation;
	public String localizedTitle;
	public String[] localizedDescription;
	
	private final ResourceLocation ICONS = new ResourceLocation(WSBIM.MODID, "textures/gui/icons.png");
	private final ResourceLocation BACKGROUND = new ResourceLocation("textures/gui/options_background.png");
	private final Minecraft mc;
	private final GuiButton okButton;
	private final GuiButton cancelButton;
	
	private boolean visible = false;
	private int width;
	private int height;
	private int xPos;
	private int yPos;
	
	//RETURN STATES
	public static final int OK_OPTION = 1;
	public static final int CANCEL = 2;
	public static final int NONE = 0;
	
	public GuiWarningMessage(Minecraft mc, boolean isMajor, boolean isConfirmation, int width, int height, String unlocalizedTitle, String...unlocalizedDescription) {
		this.mc = mc;
		this.isMajor = isMajor;
		this.isConfirmation = isConfirmation;
		this.localizedTitle = (isMajor? TextFormatting.RED : TextFormatting.GOLD) + I18n.format(unlocalizedTitle, new Object[0]);
		this.localizedDescription = new String[unlocalizedDescription.length];
		boolean flag = false;
		int longestlength = mc.fontRenderer.getStringWidth(localizedTitle);
		for(int i = 0; i < unlocalizedDescription.length; i++) {
			String line = unlocalizedDescription[i];
			this.localizedDescription[i] = (isMajor? TextFormatting.RED : TextFormatting.GOLD) + I18n.format(line, new Object[0]);
			int length = mc.fontRenderer.getStringWidth(this.localizedDescription[i]);
			if(longestlength < length) {
				flag = true;
				longestlength = length;
			}
		}
		if(!flag)this.width = width < longestlength + 56? longestlength + 56 : width;
		else this.width = width < longestlength + 20? longestlength + 20 : width;
		if(this.width < 110) this.width = 110;
		this.height = height;
		this.okButton = new GuiButton(-1225, 0, 0, 100, 20, (!isConfirmation? I18n.format("gui.done", new Object[0]) : TextFormatting.GREEN+I18n.format("gui.yes", new Object[0])));
		this.cancelButton = new GuiButton(-1226, 0, 0, 100, 20, TextFormatting.RED+I18n.format("gui.cancel", new Object[0]));
		this.okButton.visible = false;
		this.cancelButton.visible = false;
	}
	/**
	 * Sets the screen visible. Make sure you are calling the draw function correctly.
	 * @param vis
	 */
	public void setVisible(boolean vis) {
		this.visible = vis;
		this.okButton.visible = vis;
		this.cancelButton.visible = vis && this.isConfirmation;
	}
	
	public boolean isVisible() { return this.visible;}
	public void drawMessage(int screenWidth, int screenHeight, int mouseX, int mouseY, float renderTick) {
		if(this.visible) {
			this.xPos = (screenWidth / 2) - (this.width / 2);
			this.yPos = (screenHeight / 2) - (this.height / 2);
			GuiHelper.drawUIBackground(mc, BACKGROUND, xPos, yPos, this.width, this.height); //Draw dirt texture background
			int border_thickness = 2;
			GuiHelper.drawSpecificRect(xPos, yPos, xPos + this.width, yPos + border_thickness, 0, 0, 0, 1); //Draw black outlines
			GuiHelper.drawSpecificRect(xPos, yPos + this.height - border_thickness, xPos + this.width, yPos + this.height, 0, 0, 0, 1);
			GuiHelper.drawSpecificRect(xPos, yPos + border_thickness, xPos + border_thickness, this.yPos + this.height - border_thickness, 0, 0, 0, 1);
			GuiHelper.drawSpecificRect(xPos + this.width - border_thickness, yPos+border_thickness, xPos + this.width, this.yPos + this.height - border_thickness, 0, 0, 0, 1);
			this.drawCenteredString(mc.fontRenderer, this.localizedTitle, this.xPos + this.width / 2, this.yPos + 10, ColorHelper.WHITE); // Draw message text now
			for(int i = 0; i < this.localizedDescription.length; i++) {
				String renderText = this.localizedDescription[i];
				this.drawCenteredString(mc.fontRenderer, renderText, this.xPos + this.width / 2, this.yPos + 30 + (i*10), ColorHelper.WHITE);
			}
			this.okButton.x = this.xPos + (this.width / 2) - this.okButton.width / 2;
			this.okButton.y = this.yPos + this.height - (this.isConfirmation ? 50 : 25);
			if(this.isConfirmation) {
				this.cancelButton.x = this.xPos + (this.width / 2) - this.cancelButton.width / 2;
				this.cancelButton.y = this.yPos + this.height - 25;
			}
			this.okButton.drawButton(mc, mouseX, mouseY, renderTick);
			if(this.isConfirmation) this.cancelButton.drawButton(mc, mouseX, mouseY, renderTick);
			int length = mc.fontRenderer.getStringWidth(localizedTitle);
			int iconX = this.xPos + this.width / 2 - length / 2 - 20;
			int iconY = this.yPos + 6;
			mc.renderEngine.bindTexture(ICONS);
			GlStateManager.color(1, 1, 1);
			this.drawTexturedModalRect(iconX, iconY, 16, this.isMajor ? 16 : 0, 16, 16);
		}
	}
	/**
	 * Called when the mouse is clicked on this message.
	 * @param mouseX
	 * @param mouseY
	 * @param mouseButton
	 * @return
	 * @throws IOException
	 */
    public int mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException{
    	if(mouseButton != 0) return -1;
    	if(!this.visible) return -1;
    	if(this.okButton.mousePressed(mc, mouseX, mouseY)) {
    		this.okButton.playPressSound(mc.getSoundHandler());
    		return OK_OPTION;
    	}
    	if(this.cancelButton.mousePressed(mc, mouseX, mouseY) && this.isConfirmation) {
    		this.cancelButton.playPressSound(mc.getSoundHandler());
    		return CANCEL;
    	}
    	return NONE;
    }
}
