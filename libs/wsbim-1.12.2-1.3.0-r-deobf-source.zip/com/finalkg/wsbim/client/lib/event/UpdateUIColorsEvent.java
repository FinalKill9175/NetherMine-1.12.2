package com.finalkg.wsbim.client.lib.event;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.common.lib.ColorHelper;
import com.finalkg.wsbim.common.lib.WorldTimeHelper;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class UpdateUIColorsEvent {
	@SubscribeEvent
	public void onRenderTick(RenderTickEvent e){
		if(e.phase == Phase.END) { 
			Minecraft mc = Minecraft.getMinecraft();
			//Do our color control
			if(WSBIM.options.colorMode.equals(WSBIM.options.colorModes[1])){
				if(WorldTimeHelper.isDayTimeInRealLife()){
					WSBIM.options.backgroundColor = WSBIM.options.dayBackgroundColor;
					WSBIM.options.foregroundColor = WSBIM.options.dayForegroundColor;
					WSBIM.options.textColor = WSBIM.options.dayTextColor;
				}
				else{
					WSBIM.options.backgroundColor = WSBIM.options.nightBackgroundColor;
					WSBIM.options.foregroundColor = WSBIM.options.nightForegroundColor;
					WSBIM.options.textColor = WSBIM.options.nightTextColor;
				}
			}
			if(WSBIM.options.colorMode.equals(WSBIM.options.colorModes[2])){
				boolean flag = false;
				if(mc.world !=null) {
					flag = WorldTimeHelper.isDaytime(mc.world);
				}
				else if(WorldTimeHelper.isDayTimeInRealLife()) flag = true;
				if(flag){
					WSBIM.options.backgroundColor = WSBIM.options.dayBackgroundColor;
					WSBIM.options.foregroundColor = WSBIM.options.dayForegroundColor;
					WSBIM.options.textColor = WSBIM.options.dayTextColor;
				}
				else{
					WSBIM.options.backgroundColor = WSBIM.options.nightBackgroundColor;
					WSBIM.options.foregroundColor = WSBIM.options.nightForegroundColor;
					WSBIM.options.textColor = WSBIM.options.nightTextColor;
				}
			}
			else {
				WSBIM.options.backgroundColor = WSBIM.options.manualBackgroundColor;
				WSBIM.options.foregroundColor = WSBIM.options.manualForegroundColor;
				WSBIM.options.textColor = WSBIM.options.manualTextColor;
			}
		}
	}
}