package com.finalkg.wsbim.client.lib.event;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.client.lib.GuiHelper;
import com.finalkg.wsbim.common.lib.ColorHelper;
import com.finalkg.wsbim.common.lib.WorldTimeHelper;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class WSBIMWorldTimeHUDRenderEvent extends Gui{
	@SubscribeEvent
	public void onRenderGameOverlayTick(RenderGameOverlayEvent.Post e){
		Minecraft mc = Minecraft.getMinecraft();
		if(e.getType() == RenderGameOverlayEvent.ElementType.ALL) {
			if(mc.world !=null && mc.player !=null && WSBIM.options.showWorldTimeInHUD) {
				if((mc.player.isCreative() || mc.playerController.shouldDrawHUD()) && !mc.gameSettings.showDebugInfo && (!(mc.currentScreen !=null && mc.currentScreen instanceof com.finalkg.wsbim.client.gui.screen.GuiWSBIMPauseMenu))) this.renderWorldTimeInHUD(mc, mc.world, e.getResolution().getScaledWidth());
			}
		}
	}
	
	private void renderWorldTimeInHUD(Minecraft mc, WorldClient world, int screenWidth) {
		String worldTime = WorldTimeHelper.getTimeStringForMinecraftWorld(world);
		String locale = I18n.format("gui.wsbim.pausemenu.time", new Object[0]);
		String renderString = locale + " " + worldTime;
		int renderStringLength = mc.fontRenderer.getStringWidth(renderString);
		int box_thickness = 2;
		//Bug fix: other ui may take up top-center HUD space. Move it to the right side then
		int left = (mc.ingameGUI.getBossOverlay().shouldDarkenSky() || mc.ingameGUI.getBossOverlay().shouldPlayEndBossMusic() || Loader.isModLoaded("waila") ? screenWidth - renderStringLength - box_thickness - 1: screenWidth / 2 - (renderStringLength / 2));
		int box_left = left - box_thickness;
		int top = box_thickness;
		int box_right = left + renderStringLength + box_thickness + 1;
		int box_top = top - box_thickness;
		int box_bottom = box_top + (box_thickness * 2) + mc.fontRenderer.FONT_HEIGHT;
		GlStateManager.pushMatrix();
		GlStateManager.enableBlend();
		GlStateManager.enableRescaleNormal();
		GlStateManager.color(1, 1, 1, 1);
		int[] background_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.backgroundColor);
		GuiHelper.drawSpecificRect(box_left, box_top, box_right, box_bottom, background_rgb[0] / 255F, background_rgb[1] / 255F, background_rgb[2] / 255F, WSBIM.options.defaultBackgroundOpacity);
		this.drawCenteredString(mc.fontRenderer, renderString, left + (renderStringLength / 2), top, ColorHelper.convertRGBToInteger(ColorHelper.convertHexStringToRGB(WSBIM.options.textColor)));
		GlStateManager.disableBlend();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
	}
}
