package com.finalkg.wsbim.client.lib.event;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.client.lib.GuiHelper;
import com.finalkg.wsbim.common.lib.ColorHelper;
import com.finalkg.wsbim.common.lib.ContainerUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class WSBIMArmorHUDStatusRenderEvent extends Gui{
	
	private static final ResourceLocation ARMOR_SLOTS_BACKGROUND = new ResourceLocation("textures/gui/widgets.png");
	
	@SubscribeEvent
	public void onRenderGameOverlayTick(RenderGameOverlayEvent.Post e){
		Minecraft mc = Minecraft.getMinecraft();
		if(e.getType() == RenderGameOverlayEvent.ElementType.ALL) {
			if(mc.world !=null && mc.player !=null && WSBIM.options.showArmorInHUD) {
				WorldClient world = mc.world;
				EntityPlayerSP player = mc.player;
				if(player.isCreative() && !WSBIM.options.drawArmorHudInCreative) {
					return;
				}
				else if((player.isCreative() || mc.playerController.shouldDrawHUD()) && ContainerUtil.isPlayerWearingArmor(player.inventory) && !mc.gameSettings.showDebugInfo) {
					//draw HUD armor
					if(!WSBIM.options.useClearHUD) this.renderArmorInHUDVanilla(mc, player, e.getPartialTicks());
					else this.renderArmorInHUDClear(mc, player, e.getPartialTicks());
				}
			}
		}
	}

	private void renderArmorInHUDVanilla(Minecraft mc, EntityPlayerSP player, float partialTick) {
		int left = 1;
		int top = 1;
		GlStateManager.pushMatrix();
		GlStateManager.enableBlend();
		GlStateManager.enableRescaleNormal();
		GlStateManager.color(1, 1, 1, 1);
		NonNullList<ItemStack> armorSlots = player.inventory.armorInventory;
		java.util.List<ItemStack> render = new java.util.ArrayList<ItemStack>();
		for(int i = 3; i >= 0; i--) { if(!armorSlots.get(i).isEmpty()) render.add(armorSlots.get(i));}
		mc.renderEngine.bindTexture(ARMOR_SLOTS_BACKGROUND);
		this.drawTexturedModalRect(left - 1, top - 1, 1, 0, 22, 1);
		for(int i = 0; i < render.size(); i++) {
			this.drawTexturedModalRect(left - 1, top + (i * 20), 0, 1, 1, 20);
			this.drawTexturedModalRect(left - 1 + 21, top + (i * 20), 0, 1, 1, 20);
			this.drawTexturedModalRect(left, top + i * 20, 21, 1, 20, 20);
		}
		this.drawTexturedModalRect(left - 1, top + (render.size() * 20), 1, 0, 22, 1);
		GlStateManager.disableBlend();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		GlStateManager.enableRescaleNormal();
        GlStateManager.enableBlend();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		for(int i = 0; i < render.size(); i++) {
			GuiHelper.renderItemStack(mc, player, render.get(i), left + 2, top + 2 + (i * 20), partialTick);
		}
		RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.disableBlend();
	}
	private void renderArmorInHUDClear(Minecraft mc, EntityPlayerSP player, float partialTick) {
		int left = 0;
		int top = 0;
		GlStateManager.pushMatrix();
		GlStateManager.enableBlend();
		GlStateManager.enableRescaleNormal();
		GlStateManager.color(1, 1, 1, 1);
		NonNullList<ItemStack> armorSlots = player.inventory.armorInventory;
		java.util.List<ItemStack> render = new java.util.ArrayList<ItemStack>();
		for(int i = 3; i >= 0; i--) {if(!armorSlots.get(i).isEmpty()) render.add(armorSlots.get(i));}
		int[] background_rgb = ColorHelper.convertHexStringToRGB(WSBIM.options.backgroundColor);
		GuiHelper.drawSpecificRect(left, top, left + 22, top + (render.size() * 20) + 2, background_rgb[0] / 255F, background_rgb[1] / 255F, background_rgb[2] / 255F, WSBIM.options.defaultBackgroundOpacity);
		GlStateManager.disableBlend();
		GlStateManager.disableRescaleNormal();
		GlStateManager.popMatrix();
		GlStateManager.enableRescaleNormal();
        GlStateManager.enableBlend();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		for(int i = 0; i < render.size(); i++) {GuiHelper.renderItemStack(mc, player, render.get(i), left + 3, top + 3 + (i * 20), partialTick);}
		RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.disableBlend();
	}
}
