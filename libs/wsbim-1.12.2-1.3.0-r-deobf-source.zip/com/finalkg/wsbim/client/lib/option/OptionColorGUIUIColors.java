package com.finalkg.wsbim.client.lib.option;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions.OptionType;

import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class OptionColorGUIUIColors extends OptionColorGUI {

	public OptionColorGUIUIColors(Class variableClass, Object INSTANCE, boolean gui, String variableName,
			String guiName) {
		super(variableClass, INSTANCE, gui, variableName, guiName);
	}
	public boolean isOptionEnabled() { 
		if(this.variableName.equals("manualBackgroundColor") || this.variableName.equals("manualForegroundColor") || this.variableName.equals("manualTextColor")) return WSBIM.options.colorMode.equals(WSBIM.options.colorModes[0]);
		if(this.variableName.equals("dayBackgroundColor") || this.variableName.equals("dayForegroundColor") || this.variableName.equals("dayTextColor") || this.variableName.equals("nightBackgroundColor") || this.variableName.equals("nightForegroundColor") || this.variableName.equals("nightTextColor")) return !WSBIM.options.colorMode.equals(WSBIM.options.colorModes[0]);
		return true; 
	}
}
