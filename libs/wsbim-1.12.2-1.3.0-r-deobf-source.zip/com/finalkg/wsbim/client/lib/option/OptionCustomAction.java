package com.finalkg.wsbim.client.lib.option;

import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.gui.screen.options.GuiButtonOpenGUI;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public abstract class OptionCustomAction extends Option {

	/**
	 * Option with a custom action. Extend your class with this.
	 * @param variableClass
	 * @param instance
	 * @param serverSided
	 * @param variableName
	 * @param unlocalizedName
	 * @param type
	 */
	public OptionCustomAction(String unlocalizedName) {
		super(null, null, false, "", unlocalizedName, OptionType.GUI);
	}

	@Override
	public Object getObjectForCycle(int cycle) {
		return "";
	}

	@Override
	public int getCycleLength() {
		return 0;
	}

	@Override
	public int getCycleStart() {
		return 0;
	}

	@Override
	public String getStringForCycle(int cycle) {
		return "";
	}

	@Override
	public GuiScreen getGuiToOpen() {
		return null;
	}
	/**Called when the option is clicked*/
	public abstract void onOptionPressed(GuiButtonOpenGUI optionButton, Minecraft mc, int mouseX, int mouseY);
	/**Called when the button is created in the constructor.*/
	public abstract void onButtonCreation(GuiButtonOpenGUI optionButton, Minecraft mc);
	/**Called when the option is drawed.*/
	public abstract void onDraw(GuiButtonOpenGUI optionButton, Minecraft mc, int mouseX, int mouseY, float renderTick);

}
