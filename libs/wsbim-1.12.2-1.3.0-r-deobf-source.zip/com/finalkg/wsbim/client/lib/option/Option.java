package com.finalkg.wsbim.client.lib.option;

import com.finalkg.wsbim.WSBIMOptions.OptionType;

import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public abstract class Option{
	
	public final boolean clientSided;
	public String variableName;
	public OptionType type;
	public String guiName;
	public final Class variableClass;
	public final Object INSTANCE;
	
	public Option(Class variableClass, Object instance, boolean serverSided, String variableName, String unlocalizedName, OptionType type){
		this.clientSided = serverSided;
		this.variableName = variableName;
		this.guiName = I18n.format(unlocalizedName, new Object[0]);
		this.type = type;
		this.variableClass = variableClass;
		this.INSTANCE = instance;
	}
	/**Is this option enabled?*/
	public boolean isOptionEnabled() { return true; }
	public abstract Object getObjectForCycle(int cycle);
	public abstract int getCycleLength();
	public abstract int getCycleStart();
	public abstract String getStringForCycle(int cycle);
	@SideOnly(Side.CLIENT)
	public abstract GuiScreen getGuiToOpen();
}

