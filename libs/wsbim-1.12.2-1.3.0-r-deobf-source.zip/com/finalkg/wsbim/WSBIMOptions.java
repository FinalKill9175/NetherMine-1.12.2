package com.finalkg.wsbim;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import com.finalkg.wsbim.client.gui.screen.options.OptionDescriptions;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.common.lib.DummyOptionFile;
import com.finalkg.wsbim.common.lib.IOptionsFile;
import com.google.common.collect.Maps;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class WSBIMOptions {

	/**WSBIM Folder*/ 
	public File wsbimFolder = new File(FMLCommonHandler.instance().getSide() == Side.SERVER?FMLCommonHandler.instance().getMinecraftServerInstance().getFile("") : Minecraft.getMinecraft().mcDataDir, "config");
	
	/**Option File*/
	public final File optionsFile = new File(wsbimFolder, "wsbim_options.config");
	
	/**Options Map for modid*/
	private final Map<String, List<Option>> optionsMap = Maps.<String, List<Option>>newHashMap();
	
	/**Options file LIST, for other mod implementation*/
	public static final List<IOptionsFile> OPTION_FILE_LIST = new ArrayList<IOptionsFile>();
	
	/**Default WSBIM options file instance*/
	public static final IOptionsFile DUMMY_OPTIONS_FILE = new DummyOptionFile();
	
	public WSBIMOptions(){
		this.registerCustomOptionFile(WSBIM.options);
	}
	
	public void createOptions() throws IOException{

	
		if(!wsbimFolder.exists()){
			wsbimFolder.mkdir();
		}
		
		for(IOptionsFile optionFile : OPTION_FILE_LIST) {
			File f = optionFile.getOptionsFile(wsbimFolder);
			if(!f.exists()) {
				optionFile.setDefaultOptions();
				PrintWriter pw = new PrintWriter(new FileWriter(f));
				pw.println("*****WSBIM Options File for: "+optionFile.getModName()+"*****");
				pw.println("Below are all of the options for "+optionFile.getModName()+",");
				pw.println("each option is in the following format:");
				pw.println("variableName=option");
				pw.println("If there are boolean variables, change from");
				pw.println("true to false, or false to true if you want");
				pw.println("to change the variable.");
				pw.println("Written: "+new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss").format(Calendar.getInstance().getTime()));
				pw.println("Mod Version:"+optionFile.getModVersion());
				optionFile.writeOptions(pw);
				optionFile.readOptions();
			}
			else {
				boolean writeNewFile = false;
				boolean flag = false;
				try {
					BufferedReader br = new BufferedReader(new FileReader(f));
					String s = "";
			        while ((s = br.readLine()) != null){
			             try{
			            	 CharSequence charseq = ":";
			            	 if(s.contains(charseq)){
			            		String[] line = s.split(":");
			            		if(line[0].equals("Mod Version")){
			            			if(!line[1].equals(optionFile.getModVersion())){
			            				//This would reset every option when an update is installed, but thats dumb. I was probably coding this at like 3 am lmao.
			            				//So now, if the variable is not in the file it will use defaults. Makes more sense.
			            				WSBIM.logger.warn("Option file for mod \""+optionFile.getModID()+"\" was out of date. New options were set to defaults.");
			            				optionFile.setDefaultOptions();
			            				writeNewFile = true;
			            			}
			            			flag = true;
			            		}
			            	 }
			             }
			             catch(Exception e){
			            	 e.printStackTrace();
			             }
			             
			         }
					br.close();
					if(!flag) {
						WSBIM.logger.warn("Option File for mod \""+optionFile.getModID()+"\" was corrupt or unrecognizable. Defaults will be set and a new file will be written.");
						optionFile.setDefaultOptions();
						PrintWriter pw = new PrintWriter(new FileWriter(f));
						pw.println("*****WSBIM Options File for: "+optionFile.getModName()+"*****");
						pw.println("Below are all of the options for "+optionFile.getModName()+",");
						pw.println("each option is in the following format:");
						pw.println("variableName=option");
						pw.println("If there are boolean variables, change from");
						pw.println("true to false, or false to true if you want");
						pw.println("to change the variable.");
						pw.println("Written: "+new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss").format(Calendar.getInstance().getTime()));
						pw.println("Mod Version:"+optionFile.getModVersion());
						optionFile.writeOptions(pw);
					}
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				
				try {
					optionFile.readOptions();
					if(writeNewFile) {
						PrintWriter pw = new PrintWriter(new FileWriter(f));
						pw.println("*****WSBIM Options File for: "+optionFile.getModName()+"*****");
						pw.println("Below are all of the options for "+optionFile.getModName()+",");
						pw.println("each option is in the following format:");
						pw.println("variableName=option");
						pw.println("If there are boolean variables, change from");
						pw.println("true to false, or false to true if you want");
						pw.println("to change the variable.");
						pw.println("Written: "+new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss").format(Calendar.getInstance().getTime()));
						pw.println("Mod Version:"+optionFile.getModVersion());
						optionFile.writeOptions(pw);
					}
				} 
				catch (IOException e) { e.printStackTrace(); }
			}
		}
		if(FMLCommonHandler.instance().getSide() == Side.CLIENT){
			this.registerOptions();
		}
	}
	/**
	 * Allows you to register a custom IOptionsFile. MUST BE DONE IN PRE-INIT
	 * @param file
	 */
	public static void registerCustomOptionFile(IOptionsFile file) { OPTION_FILE_LIST.add(file);}
	
	public void setDefaults(){

	}
	
	public void saveAllOptions() throws IOException {
		for(IOptionsFile optionFile : WSBIMOptions.OPTION_FILE_LIST) {
			this.saveOptionsForOptionsFile(optionFile);
		}
	}
	
	public void saveOptionsForOptionsFile(IOptionsFile optionFile) throws IOException {
		File f = optionFile.getOptionsFile(wsbimFolder);
		if(f.exists()) f.delete();
		if(!f.exists()) f.createNewFile();
		PrintWriter pw = new PrintWriter(new FileWriter(f));
		pw.println("*****WSBIM Options File for: "+optionFile.getModName()+"*****");
		pw.println("Below are all of the options for "+optionFile.getModName()+",");
		pw.println("each option is in the following format:");
		pw.println("variableName=option");
		pw.println("If there are boolean variables, change from");
		pw.println("true to false, or false to true if you want");
		pw.println("to change the variable.");
		pw.println("Written: "+new SimpleDateFormat("MM/dd/yyyy-HH:mm:ss").format(Calendar.getInstance().getTime()));
		pw.println("Mod Version:"+optionFile.getModVersion());
		optionFile.writeOptions(pw);
	}

	public String convertArrayListToStrings(Object[] arr){
		String str = "";
		for(int i = 0; i < arr.length; i++){
			if(arr[i] !=null){
				if(i == 0){
					str = arr[i].toString();
				}
				else{
					str = str+", "+arr[i].toString();
				}
			}
		}
		
		return str;
	}

	@SideOnly(Side.CLIENT)
	public void registerOptions(){
		//Create DUMMY Lists first
		for(IOptionsFile file : OPTION_FILE_LIST) {
			List<Option> optionList = new ArrayList<Option>();
			for(int i = 0; i < file.getOptionListSize(); i++) optionList.add(i, null);
			this.optionsMap.put(file.getModID(), optionList);
		}
		//REGISTERS CUSTOM OPTIONS
		for(IOptionsFile file : OPTION_FILE_LIST) {
			this.optionsMap.put(file.getModID(), file.registerOptions(this.getOptionList(file.getModID())));
			file.registerOptionDescriptions();
		}
	}
	
	@SideOnly(Side.CLIENT)
	public List<Option> getOptionList(String MODID){
		return this.optionsMap.get(MODID);
	}
	
	@SideOnly(Side.CLIENT)
	public Option getOption(IOptionsFile file, int ID) {
		return this.getOptionList(file.getModID()).get(ID);
	}
	@SideOnly(Side.CLIENT)
	public static void registerOptionDescription(String varName, String...description) {
		OptionDescriptions.DESCRIPTIONS_MAP.put(varName, description);
	}
	
	public enum OptionType{
		INT,BOOLEAN,FLOAT,STRING,CYCLE,GUI,CUSTOM,COLOR;
		
		private OptionType(){
			
		}
	}
	
}
