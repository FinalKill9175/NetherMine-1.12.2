package com.finalkg.wsbim;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;

import com.finalkg.wsbim.common.command.CommandCraftingTable;
import com.finalkg.wsbim.common.net.PacketDispatcher;
import com.finalkg.wsbim.common.options.WSBIMOptionFile;
import com.finalkg.wsbim.common.proxy.CommonProxy;
import com.finalkg.wsbim.common.sound.SoundsHandler;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent.Register;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = WSBIM.MODID, name = WSBIM.NAME, version = WSBIM.VERSION, dependencies = "before:wsbim_legacy@[1.12.2-1.0.4-r,);")
public class WSBIM
{
	
	//------------ESSENTIALS BEGIN----------------//
    public static final String MODID = "wsbim";
    public static final String NAME = "What Should Be In Minecraft";
    /**FORMAT: MCVERSION-MASTER_BUILD_NUMBER.REVISION_NUMBER.BUILD_NUMBER-(a for alpha, b for beta, e for experimental, r for release)*/
    public static final int MASTER_BUILD_NUMBER = 1;
    /**FORMAT: MCVERSION-MASTER_BUILD_NUMBER.REVISION_NUMBER.BUILD_NUMBER-(a for alpha, b for beta, e for experimental, r for release)*/
    public static final int REVISION_NUMBER = 3;
    /**FORMAT: MCVERSION-MASTER_BUILD_NUMBER.REVISION_NUMBER.BUILD_NUMBER-(a for alpha, b for beta, e for experimental, r for release)*/
    public static final int BUILD_NUMBER = 0;
    /**(a for alpha, b for beta, e for experimental, r for release)*/
    public static final char BUILD_TYPE = 'r';
    /**FORMAT: MCVERSION-MASTER_BUILD_NUMBER.REVISION_NUMBER.BUILD_NUMBER-(a for alpha, b for beta, e for experimental, r for release)*/
    public static final String VERSION = "1.12.2-"+MASTER_BUILD_NUMBER+"."+REVISION_NUMBER+"."+BUILD_NUMBER+"-"+BUILD_TYPE;
    public static final String MOD_DEPENDENTS_LIST_URI = "https://www.curseforge.com/minecraft/mc-mods/what-should-be-in-mc-wsbim/relations/dependents";
    @Instance(MODID)
    public static WSBIM instance;
  
    public static Logger logger;
    
    /**OPTIONS SYSTEM INSTANCE*/
    public static final WSBIMOptionFile options = new WSBIMOptionFile();
    public static final WSBIMOptions optionsHandler = new WSBIMOptions();
    
    /**WSBIM UPDATE CHECKER INSTANCE*/
    public static WSBIMUpdateChecker updateChecker;
    
    /**PROXIES*/
	@SidedProxy(clientSide = "com.finalkg.wsbim.client.proxy.ClientProxy", serverSide = "com.finalkg.wsbim.common.proxy.CommonProxy")
	public static CommonProxy proxy;
    //------------ESSENTIALS END----------------//
    
    //------------ITEMS BEGIN------------//
	public static Item itemIronStick;
	public static Item itemGoldenStick;
	//------------ITEMS END------------//
	
	private static final Map<String, WSBIMUpdateChecker> UPDATE_CHECKER_MAP = new LinkedHashMap<String, WSBIMUpdateChecker>();
	public static final List<String> UPDATES_FOUND_BY_MODID = new ArrayList<String>();
	
    @EventHandler
    public void preInit(FMLPreInitializationEvent e)
    {
        logger = e.getModLog();
        updateChecker = new WSBIMUpdateChecker(MODID, NAME, VERSION, BUILD_TYPE, logger, "https://drive.google.com/uc?export=download&id=0BzMODdfxe3FUWlN4cnd2dkJsQ2s");
        PacketDispatcher.registerPackets();
        this.registerUpdateChecker(MODID, updateChecker);
    }

    @EventHandler
    public void init(FMLInitializationEvent e)
    {
        try {
        	optionsHandler.createOptions();
		} catch (IOException e1) {
			e1.printStackTrace();
			logger.warn("UNABLE TO CREATE OPTIONS FILE FOR WSBIM");
		}
        if(e.getSide() == Side.SERVER && WSBIM.options.checkForUpdatesOnServer){
			for(int i = 0; i < UPDATE_CHECKER_MAP.keySet().size(); i++) {
				if(UPDATE_CHECKER_MAP.get(UPDATE_CHECKER_MAP.keySet().toArray()[i]) != null) {
					WSBIMUpdateChecker updateCheck = UPDATE_CHECKER_MAP.get(UPDATE_CHECKER_MAP.keySet().toArray()[i]);
					updateCheck.checkUpdateForServer();
				}
			}
		}
        proxy.registerProxies();
        NetworkRegistry.INSTANCE.registerGuiHandler(MODID, new WSBIMGuiHandler());
    	registerSmeltingRecipes();
    	registerWorldGen();
    	registerTileEntities();
    	registerEntities();
    	SoundsHandler.registerSounds();
    }
    
    @EventHandler
    public void postInit(FMLPostInitializationEvent e) 
    {
    }
    
    @EventHandler
    public void serverLoad(FMLServerStartingEvent event)
    {
    	event.registerServerCommand(new CommandCraftingTable());
    }
    
    /**
     * Registers smelting recipes
     */
    private void registerSmeltingRecipes() {
    }

    /**
     * Registers world generators
     */
    private void registerWorldGen() {
    }
    /**
     * Registers tile entities
     */
    private void registerTileEntities() {
    }
    /**
     * Registers Entities.
     */
    private void registerEntities() {
    	
    }
    /**
     * Registers an update checker to run when the player logs into a world, or when a 
     * server is starting. 
     * MUST register IN PRE-INIT
     * @param MODID- your MODID
     * @param updateCheck - WSBIMUpdateChecker instance.
     */
    public static void registerUpdateChecker(String MODID, WSBIMUpdateChecker updateCheck) {
    	UPDATE_CHECKER_MAP.put(MODID, updateCheck);
    }
    public static Map<String, WSBIMUpdateChecker> getUpdateCheckerMap(){ return UPDATE_CHECKER_MAP; }
    /**
     * Responsible for all items and blocks being registered
     * @author ARlO-DESKTOP
     *
     */
    @EventBusSubscriber(modid = MODID)
    public static class RegistrationHandler{
    	 	@SubscribeEvent
    	    /**
    	     * Registers all items for WSBIM
    	     */
    	    public static void registerItems(Register<Item> e) 
    	    {
    	    	//Item object creation
    	    	itemIronStick = new Item().setCreativeTab(CreativeTabs.MISC).setRegistryName(MODID, "ironStick").setUnlocalizedName("ironStick");
    	    	itemGoldenStick = new Item().setCreativeTab(CreativeTabs.MISC).setRegistryName(MODID, "goldenStick").setUnlocalizedName("goldenStick");
    	    	//Item registration
    	    	e.getRegistry().register(itemIronStick);
    	    	e.getRegistry().register(itemGoldenStick);
    	    }
    	 	/**
    	     * Registers blocks for WSBIM
    	     */
    	    @SubscribeEvent
    	    public static void registerBlocks(Register<Block> e)
    	    {
    	    }
    }
   
}
