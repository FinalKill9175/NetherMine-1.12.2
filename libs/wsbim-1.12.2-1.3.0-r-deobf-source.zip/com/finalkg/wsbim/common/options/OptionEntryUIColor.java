package com.finalkg.wsbim.common.options;

import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.client.lib.option.OptionColorGUIUIColors;
import com.finalkg.wsbim.common.lib.OptionEntry;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class OptionEntryUIColor extends OptionEntry {

	private final WSBIMOptionFile opFile;
	
	public OptionEntryUIColor(WSBIMOptionFile opFile, OptionType optionType, String variableName, Object defaultValue, Object instance, Class c,
			boolean serverSided) {
		super(optionType, variableName, defaultValue, instance, c, serverSided);
		this.opFile = opFile;
	}

	@SideOnly(Side.CLIENT)
	public Option getGUIOption() {
		return new OptionColorGUIUIColors(this.opFile.getClass(), this.opFile, this.isClientSided(), this.getVariableName(), this.opFile.getModID()+".option."+this.getVariableName());
	}
}
