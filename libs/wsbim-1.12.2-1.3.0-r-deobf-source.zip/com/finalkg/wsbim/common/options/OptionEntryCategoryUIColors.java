package com.finalkg.wsbim.common.options;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.gui.screen.options.GuiWSBIMOptionsExtended;
import com.finalkg.wsbim.client.gui.screen.options.OptionCategory;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.client.lib.option.OptionGUI;
import com.finalkg.wsbim.common.lib.OptionEntry;
import com.finalkg.wsbim.common.lib.OptionFile;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class OptionEntryCategoryUIColors extends OptionEntry {

	private final WSBIMOptionFile opFile;
	
	public OptionEntryCategoryUIColors(WSBIMOptionFile opFile, String categoryName, String optionFileLine) {
		super(OptionType.CUSTOM, categoryName, optionFileLine, null, null, false);
		this.opFile = opFile;
	}
	public boolean canReadFromFile() {return false;}
	@SideOnly(Side.CLIENT)
	public Option getGUIOption() {
		Option[] options = this.opFile.getOptionsForCategory(getVariableName());
		Option[] manualColors = this.opFile.getOptionsForCategory(this.opFile.guiManualColorsCategory);
		Option[] dayColors = this.opFile.getOptionsForCategory(this.opFile.guiDaytimeColorsCategory);
		Option[] nightColors = this.opFile.getOptionsForCategory(this.opFile.guiNighttimeColorsCategory);
		if(options.length > 0 && manualColors.length > 0 && dayColors.length > 0 && nightColors.length > 0) {
			OptionCategory cat = new OptionCategory(null, options);
			OptionCategory manual_cat = new OptionCategory("wsbim.option.category."+this.opFile.guiManualColorsCategory, manualColors);
			OptionCategory day_cat = new OptionCategory("wsbim.option.category."+this.opFile.guiDaytimeColorsCategory, dayColors);
			OptionCategory night_cat = new OptionCategory("wsbim.option.category."+this.opFile.guiNighttimeColorsCategory, nightColors);
			return new OptionGUI(new GuiWSBIMOptionsExtended(this.opFile, Minecraft.getMinecraft(), "gui."+this.opFile.getModID()+".options."+this.getVariableName()+".title", false, 25, cat, manual_cat, day_cat, night_cat), this.opFile.getModID()+".option."+this.getVariableName());
		}
		else return null;
	}
}
