package com.finalkg.wsbim.common.options;

import java.io.File;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions;
import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.common.lib.ColorHelper;
import com.finalkg.wsbim.common.lib.IOptionsFile;
import com.finalkg.wsbim.common.lib.OptionEntry;
import com.finalkg.wsbim.common.lib.OptionFile;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class WSBIMOptionFile extends OptionFile {
	/**WSBIM Folder*/ 
	public static final File wsbimFolder = new File(FMLCommonHandler.instance().getSide() == Side.SERVER?FMLCommonHandler.instance().getMinecraftServerInstance().getFile("") : Minecraft.getMinecraft().mcDataDir, "config");


	//Variables
	public boolean checkForUpdatesOnServer = true;
	public boolean showScoreboard = true;
	public boolean showCrosshairs = true;
	public boolean showArmorInHUD = true;
	public boolean showContainerTabs = true;
	public boolean showInventoryTabs = true;
	public boolean showWorldTimeInHUD = false;
	public boolean useAdvancedResourcePackSupport = true;
	public boolean useResourcePackTabTexture = true;
	public boolean playOpenGUISound = false;
	public boolean drawArmorHudInCreative = true;
	public boolean useWSBIMPauseMenu = true;
	public boolean useClearHUD = true;
	//1/9/2020: Custom Item tool-tip settings
	public boolean enableNBTDataTooltips = true;
	public boolean enableDetailedTooltips = true;
	public boolean enableWSBIMItemTooltips = true;
	public String updateMode = updateModes[1];
	public String buttonLayout = buttonLayouts[2];
	public String colorMode = colorModes[2];
	public boolean useDarkGuiContainerTheme = false;
	//NOT FOR OPTIONS BUT CALLED BY OTHER CLASSES
	public String backgroundColor = "0";
	public String foregroundColor = "0xC8C8C8";
	public String textColor = "0xFFFFFF";
	//FOR OPTIONS USE
	public String manualBackgroundColor = "0";
	public String manualForegroundColor = "0xC8C8C8";
	public String manualTextColor = "0xFFFFFF";
	public String dayBackgroundColor = ColorHelper.UI_DAY_BACKGROUND_COLOR;
	public String dayForegroundColor = ColorHelper.UI_DAY_FOREGROUND_COLOR;
	public String dayTextColor = ColorHelper.UI_DAY_TEXT_COLOR;
	public String nightBackgroundColor = ColorHelper.UI_NIGHT_BACKGROUND_COLOR;
	public String nightForegroundColor = ColorHelper.UI_NIGHT_FOREGROUND_COLOR;
	public String nightTextColor = ColorHelper.UI_NIGHT_TEXT_COLOR;
	public float defaultBackgroundOpacity = 0.35F;
	public float defaultForegroundOpacity = 0.6F;
	//Cycle options
	public static final String[] updateModes = new String[]{"joinWorld", "onStartup", "off"};
	public static final String[] buttonLayouts = new String[]{"vanilla", "list", "transparent"};
	public static final String[] colorModes = new String[]{"manual", "realTime", "worldTime"};
	
	//Category Names
	private static final String hudCategory = "hudCustomization";
	private static final String guiCategory = "guiOptions";
	private static final String guiColorCategory="guiColorCategory";
	public static final String guiManualColorsCategory = "manualColors";
	public static final String guiDaytimeColorsCategory = "dayColors";
	public static final String guiNighttimeColorsCategory = "nightColors";
	private static final String guiCategoryMore = "guiOptionsMore";
	private static final String itemToolTipCategory = "tooltipSettings";
	
	public WSBIMOptionFile() {
		super(WSBIM.MODID, WSBIM.NAME, WSBIM.VERSION);
	}

	@Override
	public void addEntries() {
		this.registerCycleOptionEntry("updateMode", updateModes, 1, null, false);
		this.registerOptionEntryCategory(guiCategory, "#####GUI_CUSTOMIZATION#####");
		this.registerCycleOptionEntry("buttonLayout", buttonLayouts, 2, guiCategory, false);
		this.registerCustomOptionEntry(guiColorCategory, guiCategory, new OptionEntryCategoryUIColors(this, guiColorCategory, "###COLOR_SETTINGS###"));
		this.registerCycleOptionEntry("colorMode", colorModes, 2, guiColorCategory, false);
		this.registerColorOptionEntry("manualForegroundColor", "0xC8C8C8", guiManualColorsCategory, false);
		this.registerColorOptionEntry("manualBackgroundColor", "0", guiManualColorsCategory, false);
		this.registerColorOptionEntry("manualTextColor", "0xFFFFFF", guiManualColorsCategory, false);
		this.registerColorOptionEntry("dayForegroundColor", ColorHelper.UI_DAY_FOREGROUND_COLOR, guiDaytimeColorsCategory, false);
		this.registerColorOptionEntry("dayBackgroundColor", ColorHelper.UI_DAY_BACKGROUND_COLOR, guiDaytimeColorsCategory, false);
		this.registerColorOptionEntry("dayTextColor", ColorHelper.UI_DAY_TEXT_COLOR, guiDaytimeColorsCategory, false);
		this.registerColorOptionEntry("nightForegroundColor", ColorHelper.UI_NIGHT_FOREGROUND_COLOR, guiNighttimeColorsCategory, false);
		this.registerColorOptionEntry("nightBackgroundColor", ColorHelper.UI_NIGHT_BACKGROUND_COLOR, guiNighttimeColorsCategory, false);
		this.registerColorOptionEntry("nightTextColor", ColorHelper.UI_NIGHT_TEXT_COLOR, guiNighttimeColorsCategory, false);
		this.registerOptionEntryCategory("color_end_placeholder", "###END_OF_COLOR_OPTIONS###", false, false);
		this.registerNumberOptionEntry(OptionType.FLOAT, "defaultForegroundOpacity", 0.6F, 0.25F, 1F, 0.01F, guiCategory, false);
		this.registerNumberOptionEntry(OptionType.FLOAT, "defaultBackgroundOpacity", 0.35F, 0.25F, 1F, 0.01F, guiCategory, false);
		this.registerOptionEntry("useWSBIMPauseMenu", true, OptionType.BOOLEAN, guiCategory, false);
		this.registerOptionEntryCategory(guiCategoryMore, "#####MORE_GUI_SETTINGS#####", true, false);
		this.registerOptionEntry("playOpenGUISound", false, OptionType.BOOLEAN, guiCategoryMore, false);
		this.registerOptionEntry("showContainerTabs", true, OptionType.BOOLEAN, guiCategoryMore, false);
		this.registerOptionEntry("showInventoryTabs", true, OptionType.BOOLEAN, guiCategoryMore, false);
		this.registerOptionEntry("useResourcePackTabTexture", true, OptionType.BOOLEAN, guiCategoryMore, false);
		this.registerOptionEntry("useAdvancedResourcePackSupport", true, OptionType.BOOLEAN, guiCategoryMore, false);
		this.registerOptionEntry("useDarkGuiContainerTheme", false, OptionType.BOOLEAN, guiCategoryMore, false);
		this.registerOptionEntryCategory(hudCategory, "#####HUD_OPTIONS#####");
		this.registerOptionEntry("useClearHUD", true, OptionType.BOOLEAN, hudCategory, false);
		this.registerOptionEntry("showScoreboard", true, OptionType.BOOLEAN, hudCategory, false);
		this.registerOptionEntry("showCrosshairs", true, OptionType.BOOLEAN, hudCategory, false);
		this.registerOptionEntry("showArmorInHUD", true, OptionType.BOOLEAN, hudCategory, false);
		this.registerOptionEntry("drawArmorHudInCreative", true, OptionType.BOOLEAN, hudCategory, false); 
		this.registerOptionEntry("showWorldTimeInHUD", false, OptionType.BOOLEAN, hudCategory, false);
		this.registerOptionEntryCategory(itemToolTipCategory, "#####ITEM_TOOLTIP_SETTINGS#####");
		this.registerOptionEntry("enableWSBIMItemTooltips", true, OptionType.BOOLEAN, itemToolTipCategory, false);
		this.registerOptionEntry("enableNBTDataTooltips", true, OptionType.BOOLEAN, itemToolTipCategory, false);
		this.registerOptionEntry("enableDetailedTooltips", true, OptionType.BOOLEAN, itemToolTipCategory, false);
		this.registerOptionEntryCategory("server_placeholder", "#####SERVER_SIDE_ONLY_OPTIONS#####", false, false);
		this.registerOptionEntryNoGUI("checkForUpdatesOnServer", true, OptionType.BOOLEAN);
	}
	public void registerColorOptionEntry(String variableName, String defaultValue, String category, boolean isServerSided) {
		this.OPTION_ENTRIES.put(variableName, new OptionEntryUIColor(this, OptionType.COLOR, variableName, defaultValue, this.getOptionFileInstance(), this.getOptionFileInstance().getClass(), isServerSided));
		this.CATEGORY_MAPPING.put(variableName, category);
	}

	@Override
	public IOptionsFile getOptionFileInstance() {
		return this;
	}

	@Override
	public void registerGuiOptionDescriptions() {
		WSBIMOptions.registerOptionDescription("showContainerTabs", 
				"When enabled, a crafting table tab will appear in the top right",
				"corner of any GUI with slots. Clicking on it will open the corresponding",
				"crafting GUI depending on whether you have a crafting table in your",
				"inventory.");
	WSBIMOptions.registerOptionDescription("showCrosshairs", 					
				"Option for rendering the crosshairs in the HUD.");
	WSBIMOptions.registerOptionDescription("showScoreboard", 					
				"Option for rendering the scoreboard in the HUD.");
	WSBIMOptions.registerOptionDescription("showArmorInHUD", 					
				"Show the player's armor in the ingame GUI.");
	WSBIMOptions.registerOptionDescription("showInventoryTabs", 					
				"Display the crafting table tab in your inventory?",
				"It will only show up if you have a crafting table in your inventory.",
				"DISABLE IF MODS ARE CONFLICTING WITH INVENTORY TABS.");
	WSBIMOptions.registerOptionDescription("useAdvancedResourcePackSupport", 					
				"If enabled, WSBIM will do it's best to render out",
				"it's inventories, such as backpacks, with vanilla GUI",
				"textures. Will only have an effect if a resourcepack is loaded.",
				"DISABLE IF ANYTHING LOOKS OUT OF PLACE!");
	WSBIMOptions.registerOptionDescription("playOpenGUISound", 
				"Option for playing the 'wood click' sound effect",
				"whenever any inventory is entered.");
	WSBIMOptions.registerOptionDescription("useResourcePackTabTexture", 					
				"If enabled, WSBIM will use the currently loaded",
				"tabs.png file for rending the Crafting Table Tab.",
				"DISABLE IF the resource pack makes the tab look out of place.");
	WSBIMOptions.registerOptionDescription("updateMode", "Controls the way WSBIM will check for updates.");
	WSBIMOptions.registerOptionDescription("useWSBIMPauseMenu", 
				"Should WSBIM use a custom in-game pause menu, or should it",
				"only use the default pause menu (other mods may need it!)");
	WSBIMOptions.registerOptionDescription("defaultForegroundOpacity", 					
				"The foreground opacity used on the elements in the",
				"clear HUD, along withbuttons and labels in the WSBIM",
				"pause menu.");
	WSBIMOptions.registerOptionDescription("defaultBackgroundOpacity", 					
				"The background opacity used in rendering UI");
	WSBIMOptions.registerOptionDescription("buttonLayout", 					
				"The button layout to use on the special WSBIM menus,",
				"the pause menu and the main menu.");
	WSBIMOptions.registerOptionDescription("colorMode", 					
				"Autmatically control the color mode by the time or allow for",
				"manual control. 'Real Time' will automatically make the color",
				"scheme white on black to make it easier on the eyes when it",
				"is night time in real life. MC Time will simply do this based",
				"on the time in the minecraft world.");
	WSBIMOptions.registerOptionDescription("enableDetailedTooltips", 					
				"Shows detailed item tooltips for all items such as",
				"hunger on food or if the item can be repaired in an anvil.",
				"(Item Tooltips are when you hover over an item in your inventory)");
	WSBIMOptions.registerOptionDescription("enableUnlocalizedItemToolTips", 					
				"Shows the unlocalized name of an item or block.",
				"Other mods may already do this. Disable this option if so.",
				"This tooltip will only show up after F3+H has been pressed.",
				"(Item Tooltips are when you hover over an item in your inventory)");
	WSBIMOptions.registerOptionDescription("enableNBTDataTooltips", 					
				"Shows the NBT Tag data for the given item or block.",
				"Pressing shift will show you a list of tags and values.",
				"(Item Tooltips are when you hover over an item in your inventory)");
	WSBIMOptions.registerOptionDescription("enableWSBIMItemTooltips", 					
				"Shows special item information for items within the WSBIM mod.",
				"(Item Tooltips are when you hover over an item in your inventory)");
	WSBIMOptions.registerOptionDescription("useClearHUD", 					
				"When enabled, WSBIM will render the HUD with the set",
				"GUI colors and a sleek translucency.");
	WSBIMOptions.registerOptionDescription("drawArmorHudInCreative", 					
				"Show the Armor Status HUD in creative mode?");
	WSBIMOptions.registerOptionDescription("useDarkGuiContainerTheme", 					
				"Render internal WSBIM GUI textures with the dark theme?",
				"If Advanced Resource Pack Support is enabled, it will",
				"override the use of the dark textures when a Resource",
				"Pack is loaded.");
	WSBIMOptions.registerOptionDescription("showWorldTimeInHUD", 
			    "Will render the current world time in the HUD.");		
	}

	@Override
	public int getPrimarySlotSpacing() {
		return 25;
	}

	@SideOnly(Side.CLIENT)
	public boolean usingDarkGuiContainerTheme() {return this.useDarkGuiContainerTheme;}
	
	@SideOnly(Side.CLIENT)
	public boolean renderBasedOffVanillaTextures() {return net.minecraft.client.Minecraft.getMinecraft().gameSettings.resourcePacks.size() > 0 && this.useAdvancedResourcePackSupport;}
}
