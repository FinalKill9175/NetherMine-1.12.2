package com.finalkg.wsbim.common.item;

import net.minecraft.item.ItemHoe;

public class ItemModdedHoe extends ItemHoe {

	public ItemModdedHoe(ToolMaterial material) {
		super(material);
	}

}
