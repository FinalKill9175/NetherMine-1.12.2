package com.finalkg.wsbim.common.item;

import net.minecraft.item.ItemPickaxe;

public class ItemModdedPickaxe extends ItemPickaxe {

	public ItemModdedPickaxe(ToolMaterial material) {
		super(material);
	}

}
