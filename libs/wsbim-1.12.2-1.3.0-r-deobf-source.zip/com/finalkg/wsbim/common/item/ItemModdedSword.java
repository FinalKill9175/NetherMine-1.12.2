package com.finalkg.wsbim.common.item;

import net.minecraft.item.ItemSword;

public class ItemModdedSword extends ItemSword {

	public ItemModdedSword(ToolMaterial material) {
		super(material);
	}

}
