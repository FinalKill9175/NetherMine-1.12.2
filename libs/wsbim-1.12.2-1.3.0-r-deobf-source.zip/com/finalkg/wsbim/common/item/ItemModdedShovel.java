package com.finalkg.wsbim.common.item;

import net.minecraft.item.ItemSpade;

public class ItemModdedShovel extends ItemSpade {

	public ItemModdedShovel(ToolMaterial material) {
		super(material);
	}

}
