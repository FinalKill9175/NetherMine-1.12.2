package com.finalkg.wsbim.common.net.server;

import java.lang.reflect.Field;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.common.net.AbstractMessage.AbstractServerMessage;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;

public class OpenModGuiCustomInstance extends AbstractServerMessage<OpenModGuiCustomInstance>{
	public int id;
	public Class modClass = WSBIM.class;
	public String instanceFieldName = "instance";
	public EntityPlayer clientplayer;
	
	public OpenModGuiCustomInstance() {}

	public OpenModGuiCustomInstance(Class modClass, String instanceFieldName, int id, EntityPlayer client_player) {
		this.modClass = modClass;
		this.id = id;
		this.clientplayer = client_player;
		this.instanceFieldName = instanceFieldName;
	}

	@Override
	protected void read(PacketBuffer buffer) {
		instanceFieldName = buffer.readString(instanceFieldName.length());
		id = buffer.readInt();
	}

	@Override
	protected void write(PacketBuffer buffer) {
		buffer.writeString(instanceFieldName);
		buffer.writeInt(id);
	}

	@Override
	public void process(EntityPlayer player, Side side) {
		Field f;
		Object instance = null;
		try {
			f = this.modClass.getDeclaredField(instanceFieldName);
			f.setAccessible(true);
			try {
				instance = f.get(null);
			} catch (IllegalArgumentException | IllegalAccessException e) {
				e.printStackTrace();
			}
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		player.openGui(instance, this.id, player.world, (int) player.posX, (int) player.posY, (int) player.posZ);
	}

	public static class Handler implements IMessageHandler<OpenModGuiCustomInstance, IMessage> {
		@Override
		public IMessage onMessage(OpenModGuiCustomInstance message, MessageContext ctx) {
			EntityPlayer player = WSBIM.proxy.getPlayerEntity(ctx);
			Field f;
			Object instance = null;
			try {
				f =  message.modClass.getDeclaredField(message.instanceFieldName);
				f.setAccessible(true);
				try {
					instance = f.get(null);
				} catch (IllegalArgumentException | IllegalAccessException e) {
					e.printStackTrace();
				}
			} catch (NoSuchFieldException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			}
			player.openGui(instance, message.id, player.world, (int) player.posX, (int) player.posY, (int) player.posZ);
			return null;
		}
	}

}