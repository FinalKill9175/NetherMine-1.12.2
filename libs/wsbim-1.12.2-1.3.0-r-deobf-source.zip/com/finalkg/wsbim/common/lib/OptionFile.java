package com.finalkg.wsbim.common.lib;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.gui.screen.options.GuiWSBIMOptionsExtended;
import com.finalkg.wsbim.client.gui.screen.options.OptionCategory;
import com.finalkg.wsbim.client.lib.option.Option;
import com.finalkg.wsbim.client.lib.option.OptionBoolean;
import com.finalkg.wsbim.client.lib.option.OptionColorGUI;
import com.finalkg.wsbim.client.lib.option.OptionCycle;
import com.finalkg.wsbim.client.lib.option.OptionFloat;
import com.finalkg.wsbim.client.lib.option.OptionGUI;
import com.finalkg.wsbim.client.lib.option.OptionInteger;
import com.google.common.collect.Maps;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Allows you to create your own OptionsFile
 * Extend this class and fill implemented methods.
 * Create a variable (non-static) in your main mod class
 * and initialize the variable. Register the variable in your
 * preInit with WSBIMOptions.registerOptionsFile
 * ADD IN YOUR LANG FILE gui.(yourMODID).options.title
 * for the title of the main options menu.
 * @author finalkg
 *
 */
public abstract class OptionFile implements IOptionsFile {
	
	private final String MODID;
	private final String NAME;
	private final String MOD_VERSION;
	
	protected final Map<String, OptionEntry> OPTION_ENTRIES = new LinkedHashMap<String, OptionEntry>();
	protected final Map<String, String> CATEGORY_MAPPING = new LinkedHashMap<String, String>();
	
	private final List<Object> OPTION_CATEGORIES = new ArrayList<Object>();
	
	public OptionFile(String MODID, String MOD_NAME, String MOD_VERSION) {
		this.MODID = MODID;
		this.NAME = MOD_NAME;
		this.MOD_VERSION = MOD_VERSION;
		addEntries();
	}
	@SideOnly(Side.CLIENT)
	private void createOptionCategories() {
		List<OptionEntryCategory> categoryEntries = new ArrayList<OptionEntryCategory>();
		List<Option> mainOptions = new ArrayList<Option>();
		for(Object o : this.CATEGORY_MAPPING.keySet().toArray()) { //Add options without a category first.
			if(o instanceof String) {
				String varName = (String) o;
				if(this.CATEGORY_MAPPING.get(varName) == null || this.CATEGORY_MAPPING.get(varName).equalsIgnoreCase("null")) {
					if(this.OPTION_ENTRIES.get(varName) !=null) {
						OptionEntry entry = this.OPTION_ENTRIES.get(varName);
						if(!(entry instanceof OptionEntryCategory) && !(entry instanceof OptionEntryNoGUI)) {
							mainOptions.add(this.createOptionFromEntry(entry));
						}
					}
				}
			}
		}
		for(Object o : this.OPTION_ENTRIES.keySet().toArray()) {
			if(this.OPTION_ENTRIES.get(o) != null) {
				if(this.OPTION_ENTRIES.get(o) instanceof OptionEntryCategory) {
					categoryEntries.add((OptionEntryCategory) this.OPTION_ENTRIES.get(o));
				}
			}
		}
		if(!mainOptions.isEmpty()) {
			Option[] optionArray = new Option[mainOptions.size()];
			for(int i = 0; i < mainOptions.size(); i++) optionArray[i] = mainOptions.get(i);
			this.OPTION_CATEGORIES.add(new OptionCategory(null, optionArray));
		}
		if(!categoryEntries.isEmpty()) {
			for(int i = 0; i < categoryEntries.size(); i++) { //scan category entries to create OPTION_CATEGORIES for each one.
				OptionEntryCategory cat_entry = categoryEntries.get(i);
				List<Option> options = new ArrayList<Option>();
				for(Object o : this.OPTION_ENTRIES.values().toArray()) { // for each category scan the option entries 
					if(o instanceof OptionEntry) { //Create option for option entry and add it to the options list.
						OptionEntry entry = (OptionEntry) o;
						if(!(entry instanceof OptionEntryCategory) && !(entry instanceof OptionEntryNoGUI)) {
							if(this.CATEGORY_MAPPING.containsKey(entry.getVariableName()) && (this.CATEGORY_MAPPING.get(entry.getVariableName()) != null && this.CATEGORY_MAPPING.get(entry.getVariableName()).equalsIgnoreCase(cat_entry.getCategoryName()))) {
								options.add(this.createOptionFromEntry(entry));
							}
						}
					}
				}
				if(!options.isEmpty()) {
					if(cat_entry.hasSubMenu()) {
						Option[] optionArray = new Option[options.size()];
						for(int k = 0; k < optionArray.length; k++) optionArray[k] = options.get(k);
						OptionCategory openSubMenuButtonCategory = new OptionCategory(cat_entry.hasCategoryTitle()? this.getModID()+".option.category."+cat_entry.getCategoryName() : "", new OptionGUI(new GuiWSBIMOptionsExtended(this, Minecraft.getMinecraft(), "gui."+this.getModID()+".options."+cat_entry.getCategoryName()+".title", false, cat_entry.getSubMenuSpacing(), new OptionCategory(null, optionArray)), this.getModID()+".option."+cat_entry.getCategoryName()));
						this.OPTION_CATEGORIES.add(openSubMenuButtonCategory);
					}
					else {
						Option[] optionArray = new Option[options.size()];
						for(int k = 0; k < optionArray.length; k++) optionArray[k] = options.get(k);
						this.OPTION_CATEGORIES.add(new OptionCategory(cat_entry.hasCategoryTitle()? this.getModID()+".option.category."+cat_entry.getCategoryName() : "", optionArray));
					}
				}
			}
		}
	}
	@SideOnly(Side.CLIENT)
	private Option createOptionFromEntry(OptionEntry entry) {
		OptionType type = entry.getOptionType();
		Option entryOption = entry.getGUIOption();
		Class c = this.getOptionFileInstance().getClass();
		if(entryOption !=null) return entryOption;
		else if(type == OptionType.BOOLEAN) return new OptionBoolean(c, this.getOptionFileInstance(), entry.isClientSided(), entry.getVariableName(), this.getModID()+".option."+entry.getVariableName());
		else if(type == OptionType.COLOR) return new OptionColorGUI(c, this.getOptionFileInstance(), entry.isClientSided(), entry.getVariableName(), this.getModID()+".option."+entry.getVariableName());
		else if(type == OptionType.CYCLE) return new OptionCycle(c, this.getOptionFileInstance(), entry.isClientSided(), entry.getVariableName(), this.getModID()+".option."+entry.getVariableName(), entry.getOptionCycles());
		else if(type == OptionType.FLOAT) return new OptionFloat(c, this.getOptionFileInstance(), entry.isClientSided(), entry.getVariableName(), this.getModID()+".option."+entry.getVariableName(), (float) entry.getMinValue(), (float) entry.getMaxValue(), (float) entry.getStepping());
		else if(type == OptionType.INT) return new OptionInteger(c, this.getOptionFileInstance(), entry.isClientSided(), entry.getVariableName(), this.getModID()+".option."+entry.getVariableName(), (int) entry.getMinValue(), (int) entry.getMaxValue(), (int) entry.getStepping());
		return entryOption;
	}
	@SideOnly(Side.CLIENT)
	/**
	 * Returns an array list of options from a given category.
	 * @param category
	 * @return
	 */
	public Option[] getOptionsForCategory(String category) {
		List<Option> optionList = new ArrayList<Option>();
		for(Object o : this.CATEGORY_MAPPING.keySet().toArray()) {
			if(o instanceof String) {
				String varName = (String)o;
				if(this.CATEGORY_MAPPING.get(varName) != null && this.CATEGORY_MAPPING.get(varName).equals(category)) {
					if(this.OPTION_ENTRIES.get(varName) !=null) {
						OptionEntry entry = this.OPTION_ENTRIES.get(varName);
						if(!(entry instanceof OptionEntryCategory) && !(entry instanceof OptionEntryNoGUI)) {
							optionList.add(this.createOptionFromEntry(entry));
						}
					}
				}
			}
		}
		if(!optionList.isEmpty()) {
			Option[] options = new Option[optionList.size()];
			for(int i = 0; i < optionList.size(); i++) {options[i] = optionList.get(i);}
			return options;
		}
		else return new Option[0];
	}
	
	@SideOnly(Side.CLIENT)
	/**Used to add additional option categories to the top of the GUI*/
	public void addOptionCategories() {}
	/**
	 * Use this.registerOptionEntry(variableName, OptionEntry);
	 * or this.registerOptionEntry(variableName, String... optionCycles, int defaultValue);
	 * Make sure to place the options in order for your GUI and options file.
	 * Called in constructor, this will register all of your option entries.
	 */
	public abstract void addEntries();
	
	/**
	 * Registers an option entry for your option file.
	 * IN YOUR LANG FILE. put (your mod id).option.(variableName)=LOCALIZED NAME (used on button)
	 * @param variableName - name of the variable in your OptionFile class. Make it a public variable without setting any values defined with the variable.
	 * @param defaultValue - default value for this option.
	 * @param optionType - Option Type for this option.
	 * @param category - The name of the category to put this option under. SET TO NULL TO have this option on the main page.
	 * @param serverSided - Is this option server sided?
	 */
	public void registerOptionEntry(String variableName, Object defaultValue, OptionType optionType, String category, boolean serverSided) {
		if(optionType == OptionType.CUSTOM || optionType == OptionType.GUI) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type GUI or CUSTOM, this is NOT ALLOWED");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.STRING) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type String. String OPTIONS are currently not implemented.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.CYCLE) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type CYCLE. Please use registerCycleOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.INT || optionType == OptionType.FLOAT) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type INT OR FLOAT. Please use registerNumberOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.COLOR) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type COLOR. Please use registerColorOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		this.OPTION_ENTRIES.put(variableName, new OptionEntry(optionType, variableName, defaultValue, this.getOptionFileInstance(), this.getOptionFileInstance().getClass(), serverSided));
		this.CATEGORY_MAPPING.put(variableName, category);
	}
	/**
	 * Allows you to register your own custom option entry in a class that extends OptionEntry.
	 * Primary use is for custom Option extensions.
	 * @param variableName
	 * @param category
	 * @param entry
	 */
	public void registerCustomOptionEntry(String variableName, String category, OptionEntry entry) {
		this.OPTION_ENTRIES.put(variableName, entry);
		this.CATEGORY_MAPPING.put(variableName, category);
	}
	/**
	 * Registers a cycle option entry. 
	 * IN YOUR LANG FILE: please put (yourmodid).option.cycle.cycleName=LOCALIZED NAME
	 * for each part of the cycle.
	 * And put (your mod id).option.(variableName)=LOCALIZED NAME (used on button) for the option itself.
	 * @param variableName
	 * @param cycle - MUST BE PUBLIC AND STATIC STRING[] ARRAY
	 * @param defaultCycle
	 * @param category - The category to put the option under. SET THIS TO NULL TO HAVE THE OPTION ON THE MAIN PAGE WITHOUT A CATEGORY.
	 */
	public void registerCycleOptionEntry(String variableName, String[] cycle, int defaultCycle, String category, boolean serverSided) {
		this.OPTION_ENTRIES.put(variableName, new OptionEntry(variableName, defaultCycle, cycle, this.getOptionFileInstance(), this.getOptionFileInstance().getClass(), serverSided));
		this.CATEGORY_MAPPING.put(variableName, category);
	}
	/**
	 * Registers a number option entry for OptionType.INT or OptionType.FLOAT
	 * 	 IN YOUR LANG FILE. put (your mod id).option.(variableName)=LOCALIZED NAME (used on button)
	 * @param type TYPE FOR THE OPTION 
	 * @param variableName - name of the variable in your option file class.
	 * @param defaultValue - default value
	 * @param minValue - minimum value
	 * @param maxValue - maximum value
	 * @param stepping - Variable stepping (for the slider)
	 * @param category - category for this option. leave NULL if you want this on the main options screen.
	 */
	public void registerNumberOptionEntry(OptionType type, String variableName, Object defaultValue, Object minValue, Object maxValue, Object stepping, String category, boolean serverSided) {
		if(!(type == OptionType.INT || type == OptionType.FLOAT)) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " DOES NOT use the type INT OR FLOAT. Please use registerOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		this.OPTION_ENTRIES.put(variableName, new OptionEntry(type, variableName, defaultValue, minValue, maxValue, stepping, this.getOptionFileInstance(), this.getOptionFileInstance().getClass(), serverSided));
		this.CATEGORY_MAPPING.put(variableName, category);
	}
	/**
	 * Registers a color option entry.
	 * IN YOUR LANG FILE. put (your mod id).option.(variableName)=LOCALIZED NAME (used on button)
	 * @param variableName
	 * @param defaultValue
	 * @param category
	 */
	public void registerColorOptionEntry(String variableName, String defaultValue, String category, boolean isServerSided) {
		this.OPTION_ENTRIES.put(variableName, new OptionEntry(OptionType.COLOR, variableName, defaultValue, this.getOptionFileInstance(), this.getOptionFileInstance().getClass(), isServerSided));
		this.CATEGORY_MAPPING.put(variableName, category);
	}
	/**
	 * Registers an option entry for your option file.
	 * IN YOUR LANG FILE. put (your mod id).option.(variableName)=LOCALIZED NAME (used on button)
	 * @param variableName - name of the variable in your OptionFile class. Make it a public variable without setting any values defined with the variable.
	 * @param defaultValue - default value for this option.
	 * @param optionType - Option Type for this option.
	 */
	public void registerOptionEntryNoGUI(String variableName, Object defaultValue, OptionType optionType) {
		if(optionType == OptionType.CUSTOM || optionType == OptionType.GUI) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type GUI or CUSTOM, this is NOT ALLOWED");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.STRING) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type String. String OPTIONS are currently not implemented.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.CYCLE) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type CYCLE. Please use registerCycleOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.INT || optionType == OptionType.FLOAT) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type INT OR FLOAT. Please use registerNumberOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		else if(optionType == OptionType.COLOR) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " uses the type COLOR. Please use registerColorOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		this.OPTION_ENTRIES.put(variableName, new OptionEntryNoGUI(optionType, variableName, defaultValue, this.getOptionFileInstance(), this.getOptionFileInstance().getClass()));
	}
	/**
	 * Registers a cycle option entry. 
	 * IN YOUR LANG FILE: please put (yourmodid).option.cycle.cycleName=LOCALIZED NAME
	 * for each part of the cycle.
	 * And put (your mod id).option.(variableName)=LOCALIZED NAME (used on button) for the option itself.
	 * @param variableName
	 * @param cycle - MUST BE PUBLIC AND STATIC STRING[] ARRAY
	 * @param defaultCycle
	 * @param category - The category to put the option under. SET THIS TO NULL TO HAVE THE OPTION ON THE MAIN PAGE WITHOUT A CATEGORY.
	 */
	public void registerCycleOptionEntryNoGUI(String variableName, String[] cycle, int defaultCycle) {
		this.OPTION_ENTRIES.put(variableName, new OptionEntryNoGUI(variableName, defaultCycle, cycle, this.getOptionFileInstance(), this.getOptionFileInstance().getClass()));
	}
	/**
	 * Registers a number option entry for OptionType.INT or OptionType.FLOAT
	 * 	 IN YOUR LANG FILE. put (your mod id).option.(variableName)=LOCALIZED NAME (used on button)
	 * @param type TYPE FOR THE OPTION 
	 * @param variableName - name of the variable in your option file class.
	 * @param defaultValue - default value
	 * @param minValue - minimum value
	 * @param maxValue - maximum value
	 * @param stepping - Variable stepping (for the slider)
	 * @param category - category for this option. leave NULL if you want this on the main options screen.
	 */
	public void registerNumberOptionEntryNoGUI(OptionType type, String variableName, Object defaultValue, Object minValue, Object maxValue, Object stepping) {
		if(!(type == OptionType.INT || type == OptionType.FLOAT)) {
			try {
				throw new InvalidOptionTypeException("Option "+variableName+" from class "+this.getOptionFileInstance().getClass()+ "on mod" + this.getOptionFileInstance().getModName()+ " DOES NOT use the type INT OR FLOAT. Please use registerOptionEntry instead.");
			} catch (InvalidOptionTypeException e) {
				e.printStackTrace();
				FMLCommonHandler.instance().raiseException(e, e.getMessage(), true);
			}
			return;
		}
		this.OPTION_ENTRIES.put(variableName, new OptionEntryNoGUI(type, variableName, defaultValue, minValue, maxValue, stepping, this.getOptionFileInstance(), this.getOptionFileInstance().getClass()));
	}
	/**
	 * Registers a color option entry.
	 * IN YOUR LANG FILE. put (your mod id).option.(variableName)=LOCALIZED NAME (used on button)
	 * @param variableName
	 * @param defaultValue
	 * @param category
	 */
	public void registerColorOptionEntryNoGUI(String variableName, String defaultValue) {
		this.OPTION_ENTRIES.put(variableName, new OptionEntryNoGUI(OptionType.COLOR, variableName, defaultValue, this.getOptionFileInstance(), this.getOptionFileInstance().getClass()));
	}
	/**
	 * Registers a category for your options file.
	 * IN YOUR LANG FILE:
	 * if isSubMenu is true: put gui.(your_mod_id).options.(categoryName).title=LOCALIZED SUB MENU TITLE
	 * and (reguardless of sub menu being true, put (your_mod_id).options.category.(categoryName)=LOCALIZED CATEGORY NAME (will appear on button or above the options)
	 * @param categoryName - Name for the category. Used in LANG files.
	 * @param optionFileLine - Line to print for this category in the options file. IF the options are server side, write a warning here.
	 * @param isSubMenu - Will the option category have all of the options below it sorted into a sub menu? Or will it appear on the main options page?
	 * @param subMenuSpacing - Only needed if isSubMenu is true. Use 25 for good spacing.
	 */
	public void registerOptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu, int subMenuSpacing) {
		this.OPTION_ENTRIES.put(categoryName, new OptionEntryCategory(categoryName, optionFileLine, isSubMenu, subMenuSpacing));
	}
	/**
	 * Registers a category for your options file.
	 * IN YOUR LANG FILE:
	 * if isSubMenu is true: put gui.(your_mod_id).options.(categoryName).title=LOCALIZED SUB MENU TITLE
	 * and (reguardless of sub menu being true, put (your_mod_id).option.category.(categoryName)=LOCALIZED CATEGORY NAME (will appear on button or above the options)
	 * @param categoryName - Name for the category. Used in LANG files.
	 * @param optionFileLine - Line to print for this category in the options file. IF the options are server side, write a warning here.
	 * @param isSubMenu - Will the option category have all of the options below it sorted into a sub menu? Or will it appear on the main options page?
	 */
	public void registerOptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu) {
		this.OPTION_ENTRIES.put(categoryName, new OptionEntryCategory(categoryName, optionFileLine, isSubMenu));
	}
	/**
	 * Registers a category for your options file.
	 * IN YOUR LANG FILE:
	 * if isSubMenu is true: put gui.(your_mod_id).options.(categoryName).title=LOCALIZED SUB MENU TITLE
	 * and (reguardless of sub menu being true, put (your_mod_id).option.category.(categoryName)=LOCALIZED CATEGORY NAME (will appear on button or above the options)
	 * @param categoryName - Name for the category. Used in LANG files.
	 * @param optionFileLine - Line to print for this category in the options file. IF the options are server side, write a warning here.
	 * @param isSubMenu - Will the option category have all of the options below it sorted into a sub menu? Or will it appear on the main options page?
	 * @param hasCategoryTitle - Will this option category still retain its category title on the main page?
	 */
	public void registerOptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu, boolean hasCategoryTitle) {
		this.OPTION_ENTRIES.put(categoryName, new OptionEntryCategory(categoryName, optionFileLine, isSubMenu, hasCategoryTitle));
	}
	/**
	 * Registers a category for your options file.
	 * IN YOUR LANG FILE:
	 * if isSubMenu is true: put gui.(your_mod_id).options.(categoryName).title=LOCALIZED SUB MENU TITLE
	 * and (reguardless of sub menu being true, put (your_mod_id).option.category.(categoryName)=LOCALIZED CATEGORY NAME (will appear on button or above the options)
	 * @param categoryName - Name for the category. Used in LANG files.
	 * @param optionFileLine - Line to print for this category in the options file. IF the options are server side, write a warning here.
	 * @param isSubMenu - Will the option category have all of the options below it sorted into a sub menu? Or will it appear on the main options page?
	 * @param hasCategoryTitle - Will this option category still retain its category title on the main page?
	 * @param subMenuSpacing - Sub menu spacing parameter Use 25 for good spacing
	 */
	public void registerOptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu, boolean hasCategoryTitle, int subMenuSpacing) {
		this.OPTION_ENTRIES.put(categoryName, new OptionEntryCategory(categoryName, optionFileLine, isSubMenu, hasCategoryTitle, subMenuSpacing));
	}
	/**
	 * Registers a category for your options file.
	 * IN YOUR LANG FILE:
	 * put (your_mod_id).option.category.(categoryName)=LOCALIZED CATEGORY NAME (appears above the options)
	 * @param categoryName - Name for the category. Used in LANG files.
	 * @param optionFileLine - Line to print for this category in the options file. IF the options are server side, write a warning here.
	 */
	public void registerOptionEntryCategory(String categoryName, String optionFileLine) {
		this.OPTION_ENTRIES.put(categoryName, new OptionEntryCategory(categoryName, optionFileLine));
	}
	
	/**Returns the instance of your options file from your main mod class. ie WSBIM.options, or you can return "this"*/
	public abstract IOptionsFile getOptionFileInstance();
	
	@Override
	public void writeOptions(PrintWriter printWriter) {
		for(Object o : this.OPTION_ENTRIES.keySet().toArray()) {
			OptionEntry entry = this.OPTION_ENTRIES.get(o);
			if(entry !=null) entry.writeOptionEntry(printWriter);
		}
		printWriter.println("#####END OF OPTIONS#####");
		printWriter.close();
	}

	@Override
	public void readOptions() {
		Map<OptionEntry, Boolean> foundEntries = new LinkedHashMap<OptionEntry, Boolean>();
		for(Object o : OPTION_ENTRIES.keySet().toArray()) {
			if(o != null && OPTION_ENTRIES.get(o) !=null) {
				OptionEntry entry = OPTION_ENTRIES.get(o);
				if(entry.canReadFromFile()) {
					foundEntries.put(entry, false);
				}
			}
		}
		BufferedReader bufferedreader = null;
		try {
			bufferedreader = new BufferedReader(new FileReader(this.getOptionsFile(null)));
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
        String s = "";
        try {
			while ((s = bufferedreader.readLine()) != null){
			    try{
			   	 	CharSequence charseq = "=";
			   	 	if(s.contains(charseq)){
			   	 		String[] line = s.split("=");
			   			if(this.OPTION_ENTRIES.containsKey(line[0])) {
			   				OptionEntry entry = this.OPTION_ENTRIES.get(line[0]);
			   				if(entry !=null) {
			   					entry.readOptionEntry(line[0], line[1]);
			   					if(foundEntries.containsKey(entry)) {
			   						foundEntries.remove(entry);
			   						foundEntries.put(entry, true);
			   					}
			   				}
			   			}
			   	 	}
			    }
			    catch(Exception e){
			  
			    }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
        try {
			bufferedreader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
        for(Object o : foundEntries.keySet().toArray()) {
        	if(o !=null && o instanceof OptionEntry) {
        		OptionEntry entry = (OptionEntry)o;
        		if(!foundEntries.get(entry)) {
        			entry.setDefaultValue(true); // set defaults if they are not found in the file.
        		}
        	}
        }
	}

	@Override
	public void setDefaultOptions() {
		for(Object o : this.OPTION_ENTRIES.keySet().toArray()) {
			OptionEntry entry = this.OPTION_ENTRIES.get(o);
			if(entry !=null && !(entry instanceof OptionEntryCategory)) entry.setDefaultValue(false);
		}
	}
	
	@Override
	public File getOptionsFile(File configFolder) {
		return new File(this.getOptionsFolder(), MODID+".config");
	}
	/**
	 * Can be overriden to a folder of your choice. Defaults to mcdir/config
	 * @return
	 */
	public File getOptionsFolder() {
		return WSBIM.optionsHandler.wsbimFolder;
	}
	
	@Override
	public String getModVersion() {
		return MOD_VERSION;
	}

	@Override
	public String getModName() {
		return NAME;
	}

	@Override
	public String getModID() {
		return MODID;
	}

	@Override @Deprecated/**DO NOT OVERRIDE THIS METHOD*/
	public int getOptionListSize() {
		return 1;
	}

	@Override @SideOnly(Side.CLIENT) @Deprecated
	public List<Option> registerOptions(List<Option> optionsList) {
		return optionsList;
	}

	@Override
	public void registerOptionDescriptions() {
		registerGuiOptionDescriptions();
	}
	/**Use WSBIMOptions.registerOptionDescription("variableName", String... description)
	 * This is for GUI hover text 
	 */
	@SideOnly(Side.CLIENT)
	public abstract void registerGuiOptionDescriptions();

	@Override @SideOnly(Side.CLIENT)
	public OptionGUI getMainGUI() {
		this.OPTION_CATEGORIES.clear();
		this.addOptionCategories();
		this.createOptionCategories();
		if(this.OPTION_CATEGORIES.isEmpty()) return null;
		OptionCategory[] cat_array = new OptionCategory[this.OPTION_CATEGORIES.size()];
		for(int i = 0; i < this.OPTION_CATEGORIES.size(); i++) cat_array[i] = (OptionCategory) this.OPTION_CATEGORIES.get(i);
		return new OptionGUI(new GuiWSBIMOptionsExtended(this, Minecraft.getMinecraft(), "gui."+this.getModID()+".options.title", true, this.getPrimarySlotSpacing(), cat_array), "gui.wsbim.button.options");
	}
	
	/**Spacing for option slots on the primary options GUI*/
	public abstract int getPrimarySlotSpacing();
}
