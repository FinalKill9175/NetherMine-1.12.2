package com.finalkg.wsbim.common.lib;

import com.finalkg.wsbim.WSBIMOptions.OptionType;

public class OptionEntryCategory extends OptionEntry {
	
	private final boolean hasSubMenu;
	private final int subMenuSpacing;
	private final boolean hasCategoryTitle;

	public OptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu, boolean hasCategoryTitle, int subMenuSpacing) {
		super(OptionType.CUSTOM, categoryName, optionFileLine, null, null, false);
		this.hasSubMenu = isSubMenu;
		this.subMenuSpacing = subMenuSpacing;
		this.hasCategoryTitle = hasCategoryTitle;
	}
	public OptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu, int subMenuSpacing) {
		super(OptionType.CUSTOM, categoryName, optionFileLine, null, null, false);
		this.hasSubMenu = isSubMenu;
		this.subMenuSpacing = subMenuSpacing;
		this.hasCategoryTitle = !isSubMenu;
	}
	public OptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu, boolean hasCategoryTitle) {
		super(OptionType.CUSTOM, categoryName, optionFileLine, null, null, false);
		this.hasSubMenu = isSubMenu;
		this.subMenuSpacing = 25;
		this.hasCategoryTitle = hasCategoryTitle;
	}
	public OptionEntryCategory(String categoryName, String optionFileLine, boolean isSubMenu) {
		super(OptionType.CUSTOM, categoryName, optionFileLine, null, null, false);
		this.hasSubMenu = isSubMenu;
		this.subMenuSpacing = 25;
		this.hasCategoryTitle = !isSubMenu;
	}
	public OptionEntryCategory(String categoryName, String optionFileLine) {
		super(OptionType.CUSTOM, categoryName, optionFileLine, null, null, false);
		this.hasSubMenu = false;
		this.subMenuSpacing = 25;
		this.hasCategoryTitle = true;
	}
	protected boolean hasCategoryTitle() {return this.hasCategoryTitle; }
	protected boolean hasSubMenu() { return this.hasSubMenu; }
	protected int getSubMenuSpacing() {return this.subMenuSpacing;}
	public String getCategoryName() { return super.getVariableName();}
	public boolean canReadFromFile() {return false;}
}
