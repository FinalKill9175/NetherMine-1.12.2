package com.finalkg.wsbim.common.lib;

import com.finalkg.wsbim.WSBIMOptions.OptionType;

public class DummyOptionFile extends OptionFile {

	public String testColor;
	public String testColor2;
	public int testInteger;
	public float testFloat;
	public boolean testBoolean;
	public String testCycle;
	public static final String[] testCycles = {"string1","string2","string3"};
	public final String testCategory = "testCategory";
	public final String testSubCategory = "testSubCategory";
	
	public DummyOptionFile() {
		super("dummy_mod", "Dummy Mod", "1.12.2-1.0.0-r");
	}

	@Override
	public void addEntries() {
		this.registerOptionEntryCategory(testSubCategory, "#####TEST_SUB_CATEGORY#####", true, true);
		this.registerColorOptionEntry("testColor2", "0", testSubCategory, false);
		this.registerOptionEntryCategory(testCategory, "#####TEST_CATEGORY#####");
		this.registerColorOptionEntry("testColor", "0", testCategory, false);
		this.registerNumberOptionEntry(OptionType.INT, "testInteger", 25, 0, 100, 1, testCategory, false);
		this.registerNumberOptionEntry(OptionType.FLOAT, "testFloat", 0.3F, 0F, 1F, 0.01F, testCategory, false);
		this.registerOptionEntry("testBoolean", true, OptionType.BOOLEAN, testCategory, false);
		this.registerCycleOptionEntry("testCycle", testCycles, 1, testCategory, false);

	}

	@Override
	public IOptionsFile getOptionFileInstance() {
		return this;
	}

	@Override
	public void registerGuiOptionDescriptions() {

	}

	@Override
	public int getPrimarySlotSpacing() {
		return 25;
	}

}
