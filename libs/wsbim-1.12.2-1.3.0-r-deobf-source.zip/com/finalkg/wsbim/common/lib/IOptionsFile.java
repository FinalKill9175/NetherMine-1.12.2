package com.finalkg.wsbim.common.lib;

import java.io.File;
import java.io.PrintWriter;
import java.util.List;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * REGISTER THIS OPTION FILE INSTANCE IN PRE-INIT
 * WITH WSBIMOptions.registerCustomOptionsFile(IOptionsFile instance)
 * @author finalkg
 *
 */
public interface IOptionsFile {

	/**
	 * Writes the options to a file. Already checks to see if the options file exists, and writes essential data.
	 * Just do writing here.
	 * Example: 
	 * pw.println(OPTION_TEXT+":"+OPTION_VARIABLE)
	 * MUST INCLUDE pw.close();!
	 */
	public void writeOptions(PrintWriter printWriter);
	/**
	 * Reads the options from the file and updates the variable names.
	 * Use java.io.bufferedReader
	 * Check each string in the array to set option variables. See WSBIMOptions.loadOptions for examples.
	 */
	public void readOptions();
	/**
	 * Sets the option values to their defaults
	 */
	public void setDefaultOptions();
	/**
	 * Gets the options file to write the options to.
	 * @return Options file RETURN new File(configFolder, "YOUR_MOD_NAME_options.config");
	 */
	public File getOptionsFile(File configFolder);
	
	/**
	 * Gets the mod version.
	 * Checks for this during loading to account for changes.
	 * @return
	 */
	public String getModVersion();
	
	/**
	 * Used for writing purposes.
	 * @return
	 */
	public String getModName();
	public String getModID();
	/**Gets the size for the options list. Make this larger than the number of IDs on your list
	 * 1.3.0 MARKED FOR REMOVAL WITH OTHER METHOD FOR NEXT MC VERSION 
	 */
	@Deprecated
	public int getOptionListSize();
	
	/**
	 * 1.3.0 - MARKED FOR REMOVAL FOR NEXT MC VERSION. USE getMainGUI method to setup options instead. DO NOT use option IDs, rather OptionCategory
	 * Adds the options to the options GUI.
	 * DO NOT use optionsList.add, rather use optionsList.set(ID, OPTION)
	 * GUI relies on the option ID for rendering and other calls.
	 * @param optionsList
	 * MUST Register options with (example)
	 * optionsList.set(ID, new OptionBoolean(this.getClass(), <INSTANCE OF THIS CLASS>, true, "variableName", "unlocalizedname");
	 * @return Modified list. MUST RETURN THIS!
	 * 
	 */
	@SideOnly(Side.CLIENT) @Deprecated
	public List<com.finalkg.wsbim.client.lib.option.Option> registerOptions(List<com.finalkg.wsbim.client.lib.option.Option> optionsList);
	
	/**
	 * Use WSBIMOptions.registerOptionDescription(String variableName, String... description)
	 */
	@SideOnly(Side.CLIENT)
	public void registerOptionDescriptions();
	
	/**
	 * Option for opening the main options GUI for this options file.
	 * @return Main GUI Option
	 * Example: return new OptionGUI(new GuiWSBIMOptionsExtended(this, Minecraft.getMinecraft(), 0, 8, "gui.wsbim.options.title"), "gui.wsbim.button.options");
	 */
	@SideOnly(Side.CLIENT)
	public com.finalkg.wsbim.client.lib.option.OptionGUI getMainGUI();
}
