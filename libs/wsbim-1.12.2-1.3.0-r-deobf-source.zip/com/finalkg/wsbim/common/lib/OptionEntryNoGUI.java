package com.finalkg.wsbim.common.lib;

import com.finalkg.wsbim.WSBIMOptions.OptionType;

public class OptionEntryNoGUI extends OptionEntry {

	public OptionEntryNoGUI(OptionType optionType, String variableName, Object defaultValue, Object instance, Class c) {
		super(optionType, variableName, defaultValue, instance, c, true);
	}

	public OptionEntryNoGUI(String variableName, int defaultCycle, String[] cycles, Object instance, Class c) {
		super(variableName, defaultCycle, cycles, instance, c, true);
	}

	public OptionEntryNoGUI(OptionType optionType, String variableName, Object defaultValue, Object min, Object max, Object stepping, Object instance, Class c) {
		super(optionType, variableName, defaultValue, min, max, stepping, instance, c, true);
	}

}
