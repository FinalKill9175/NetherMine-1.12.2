package com.finalkg.wsbim.common.lib;

import java.io.PrintWriter;
import java.lang.reflect.Field;

import com.finalkg.wsbim.WSBIM;
import com.finalkg.wsbim.WSBIMOptions.OptionType;
import com.finalkg.wsbim.client.lib.option.Option;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class OptionEntry {

	private final OptionType type;
	private final String variableName;
	private final Object defaultValue;
	private final Object instance;
	private final String[] cycles;
	private final Object minValue;
	private final Object maxValue;
	private final Object stepping;
	private final boolean isServerSide;
	private final int defaultCycle;
	
	public OptionEntry(OptionType optionType, String variableName, Object defaultValue, Object instance, Class c, boolean serverSided){
		this.type = optionType;
		this.variableName = variableName;
		this.defaultValue = defaultValue;
		this.instance = instance;
		this.cycles = null;
		this.minValue = null;
		this.maxValue = null;
		this.stepping = null;
		this.isServerSide = serverSided;
		this.defaultCycle = 0;
	}
	public OptionEntry(String variableName, int defaultCycle, String[] cycles, Object instance, Class c, boolean serverSided){
		this.type = OptionType.CYCLE;
		this.variableName = variableName;
		this.cycles = cycles;
		this.defaultValue = null;
		this.defaultCycle = defaultCycle;
		this.instance = instance;
		this.minValue = null;
		this.maxValue = null;
		this.stepping = null;
		this.isServerSide = serverSided;
	}
	public OptionEntry(OptionType optionType, String variableName, Object defaultValue, Object min, Object max, Object stepping, Object instance, Class c, boolean serverSided){
		this.type = optionType;
		this.variableName = variableName;
		this.defaultValue = defaultValue;
		this.instance = instance;
		this.cycles = null;
		this.minValue = min;
		this.maxValue = max;
		this.stepping = stepping;
		this.isServerSide = serverSided;
		this.defaultCycle = 0;
	}
	protected void writeOptionEntry(PrintWriter pw) {
		if(this.type == OptionType.CUSTOM) pw.println(this.defaultValue);
		else pw.println(variableName+getDivider()+this.getObjectFromClass(variableName, this.instance.getClass(), this.instance));
	}
	
	protected void readOptionEntry(String line0, String line1) {
		if(type == OptionType.INT && line0.equals(variableName)) {
			int parsed = Integer.parseInt(line1);
			if(this.qualifiesForInteger(parsed)) this.setObjectInClass(Integer.parseInt(line1), variableName, instance, instance.getClass(), false);
			else this.setDefaultValue(true);
		}
		else if(type == OptionType.FLOAT && line0.equals(variableName)) {
			float parsed = Float.parseFloat(line1);
			if(this.qualifiesForFloat(parsed)) this.setObjectInClass(Float.parseFloat(line1), variableName, instance, instance.getClass(), false);
			else this.setDefaultValue(true);
		}
		else if(type == OptionType.COLOR && line0.equals(variableName)) {
			if(line1.equals("null")) this.setDefaultValue(true);
			else this.setObjectInClass(line1, variableName, instance, instance.getClass(), false);
		}
		else if(type == OptionType.BOOLEAN && line0.equals(variableName)) this.setObjectInClass(Boolean.parseBoolean(line1), variableName, instance, instance.getClass(), false);
		else if(type == OptionType.CYCLE && line0.equals(variableName)) this.setObjectInClass(this.qualifiesForCycle(line1) ? line1 : this.cycles[defaultCycle], variableName, instance, instance.getClass(), false);
		else if((type == OptionType.STRING  || type == OptionType.COLOR) && line0.equals(variableName)) this.setObjectInClass(line1, variableName, instance, instance.getClass(), false);
		else if(type == OptionType.CUSTOM || type == OptionType.GUI) return;
		else {
			this.setDefaultValue(true);
		}
	}
	protected void setDefaultValue(boolean failed) {
		if(type == OptionType.CUSTOM || type == OptionType.GUI) return;
		if(type == OptionType.CYCLE) this.setObjectInClass(cycles[defaultCycle], variableName, instance, instance.getClass(), failed);
		else this.setObjectInClass(defaultValue, variableName, instance, instance.getClass(), failed);
	}
	
	private void setObjectInClass(Object o, String varName, Object instance, Class clazz, boolean fail) {
		Field f = null;
		try {
			f = clazz.getDeclaredField(varName);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		f.setAccessible(true);
		try {
			f.set(instance, o);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			e.printStackTrace();
		}
		if(fail) {
			WSBIM.logger.warn("Option Entry for "+this.variableName + " in mod option class "+this.instance.getClass() + " failed to read. It was set to the default value "+this.defaultValue);
		}
	}
    /**
     * Uses java reflect to get a variable from a initialized class.
     * @param varName
     * @param clazz
     * @param instance
     * @return
     */
	public static Object getObjectFromClass(String varName, Class<?> clazz, Object instance){
		Field f = null;
		try {
			f = clazz.getDeclaredField(varName);
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		}
		f.setAccessible(true);
		
		try {
			return f.get(instance);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
	private boolean qualifiesForCycle(String check) {
		if(this.cycles == null) return false;
		boolean flag = false;
		for(String s : cycles) {
			if(s.equalsIgnoreCase(check)) flag = true;
		}
		return flag;
	}
	@SideOnly(Side.CLIENT)
	/**Over ride this and return whatever GUI option you want to appear.*/
	public Option getGUIOption() {
		return null;
	}
	private boolean qualifiesForInteger(int check) {
		int min = (int) this.minValue;
		int max = (int) this.maxValue;
		return check <= max && check >= min;
	}
	private boolean qualifiesForFloat(float check) {
		float min = (float) this.minValue;
		float max = (float) this.maxValue;
		return check <= max && check >= min;
	}
	public OptionType getOptionType() {return this.type; }
	public String getVariableName() { return variableName; }
	public String getDivider() { return "="; }
	public String[] getOptionCycles() { return this.cycles != null ? this.cycles : new String[0];}
	protected boolean isServerSided() {return this.isServerSide; }
	protected boolean isClientSided() {return !this.isServerSided();}
	protected Object getInstance() { return this.instance;}
	protected Object getMinValue() { return this.minValue;}
	protected Object getMaxValue() {return this.maxValue;}
	protected Object getStepping() {return this.stepping;}
	/**Can this option entry be read from this file*/
	public boolean canReadFromFile() {return true;}
}
