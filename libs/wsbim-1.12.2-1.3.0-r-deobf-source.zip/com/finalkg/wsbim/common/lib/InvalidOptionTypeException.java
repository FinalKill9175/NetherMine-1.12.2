package com.finalkg.wsbim.common.lib;

public class InvalidOptionTypeException extends Exception {

	public InvalidOptionTypeException(String string) {
		super(string);
	}

}
