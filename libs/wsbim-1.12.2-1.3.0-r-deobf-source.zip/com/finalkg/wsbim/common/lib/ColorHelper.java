package com.finalkg.wsbim.common.lib;

import java.awt.Color;

import net.minecraft.block.Block;
import net.minecraft.block.BlockColored;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemDye;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

/**Contains static color values and functions to aid in coloring*/
public class ColorHelper {

	public static final int GUI_CONTAINER_TEXT_COLOR = 4210752;
	public static final int GUI_CONTAINER_TEXT_COLOR_LIGHT = convertRGBToInteger(230, 230, 230);
	public static final int LEATHER_ARMOR_DEFAULT_COLOR = 10511680;
	public static final int WHITE = 16777215;
	public static final int ALL_BLACK = 0;
	public static final int ORANGE = 16351261;
	public static final int MAGENTA = 13061821;
	public static final int LIGHT_BLUE = 3847130;
	public static final int YELLOW = 16701501;
	public static final int LIME = 8439583;
	public static final int PINK = 15961002;
	public static final int GRAY = 4673362;
	public static final int SILVER = 10329495;
	public static final int CYAN = 1481884;
	public static final int PURPLE = 8991416;
	public static final int BLUE = 3949738;
	public static final int BROWN = 8606770;
	public static final int GREEN = 6192150;
	public static final int RED = 11546150;
	public static final int BLACK = 1908001;

	//Default Colors
	public static final String UI_DAY_FOREGROUND_COLOR = "0x323232";
	public static final String UI_DAY_BACKGROUND_COLOR = "0xC8C8C8";
	public static final String UI_DAY_TEXT_COLOR = "0xFFFFFF";
	public static final String UI_NIGHT_FOREGROUND_COLOR = "0x7D7D7D";
	public static final String UI_NIGHT_BACKGROUND_COLOR = "0x0F0F0F";
	public static final String UI_NIGHT_TEXT_COLOR = "0xFFFFFF";
	
	//RETURN_STATES
	public static final int RECOLOR_NONE = 0;
	public static final int RECOLOR_NBT = 1;
	public static final int RECOLOR_METADATA = 2;
	
	/**
	* Remove the color from the specified armor ItemStack.
	*/
	public static void removeColor(ItemStack stack){
		NBTTagCompound nbttagcompound = stack.getTagCompound();
		if(nbttagcompound != null){
			NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("display");
		    if(nbttagcompound1.hasKey("color")){
		    	nbttagcompound1.removeTag("color");
		    }
		}
	}

	/**
	* Sets the color of the specified armor ItemStack
	*/
	public static void setColor(ItemStack stack, int color){
		NBTTagCompound nbttagcompound = stack.getTagCompound();
		if(nbttagcompound == null){
			nbttagcompound = new NBTTagCompound();
		    stack.setTagCompound(nbttagcompound);
		}
		NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("display");
		if(!nbttagcompound.hasKey("display", 10)){
			nbttagcompound.setTag("display", nbttagcompound1);
		}
		nbttagcompound1.setInteger("color", color);
	}
	
	/**
	 * Checks to see if the given item stack is eligible for recoloring
	 * @param stack - Item stack to check
	 * @return RECOLOR_METADATA, RECOLOR_NBT, RECOLOR_NONE
	 */
	public static int getItemStackRecolorType(ItemStack stack) {
		if(stack.isEmpty()) return RECOLOR_NONE;
		if(!(stack.getItem() instanceof ItemBlock)) return RECOLOR_NONE;
		if(stack.getItem() instanceof ItemBlock) {
			Block b = Block.getBlockFromItem(stack.getItem());
			if(b instanceof BlockColored) {
				return RECOLOR_METADATA;
			}
		}
		if(getColor(stack) != -1 || stack.getItem() instanceof ItemBlock) return RECOLOR_NBT;
		return RECOLOR_NONE;
	}
	/**
	 * Checks to see if the block can be recolored by NBT
	 * @param stack
	 * @return
	 */
	public static boolean canBlockBeRecoloredByNBT(Block block) {return getItemStackRecolorType(new ItemStack(block)) == RECOLOR_NBT;}
	/**
	 * Checks to see if the block can be recolored by block metadata.
	 * @param block
	 * @return
	 */
	public static boolean canBlockBeRecoloredByMetadata(Block block) {return getItemStackRecolorType(new ItemStack(block)) == RECOLOR_METADATA;}
	/**
	 * Checks to see if the item can be recolored by NBT
	 * @param stack
	 * @return
	 */
	public static boolean canItemStackBeRecoloredByNBT(ItemStack stack) {return getItemStackRecolorType(stack) == RECOLOR_NBT;}
	/**
	 * Checks to see if the item can be recolored by block metadata.
	 * @param block
	 * @return
	 */
	public static boolean canItemStackBeRecoloredByMetadata(ItemStack stack) {return getItemStackRecolorType(stack) == RECOLOR_METADATA;}
	/**
	 * Checks to see if the itemstack can be recolored.
	 * @param stack
	 * @return
	 */
	public static boolean canItemStackBeRecolored(ItemStack stack) { return canItemStackBeRecoloredByNBT(stack) || canItemStackBeRecoloredByMetadata(stack); }
	/**
	 * Returns a recolored itemstack. Will keep stack sizes!!!
	 * @param stack - ItemStack
	 * @param color - EnumDyeColor
	 * @return recolored ItemStack. Returns Empty if the itemstack cannot be recolored.
	 */
	public static ItemStack getRecoloredItemStack(ItemStack stack, EnumDyeColor color) {
		if(canItemStackBeRecoloredByNBT(stack)) {
			ItemStack copy = stack.copy();
			setColor(copy, color.getColorValue());
			return copy;
		}
		if(canItemStackBeRecoloredByMetadata(stack)) return new ItemStack(stack.getItem(), stack.getCount(), color.getMetadata());
		return ItemStack.EMPTY;
	}
	/**Returns a recolored itemstack. Uses specified stack size.
	 * @param stack - ItemStack
	 * @param color - EnumDyeColor
	 * @param stackSize - Stack size to use
	 * @return recolored ItemStack. Returns Empty if the itemstack cannot be recolored.
	 */
	public static ItemStack getRecoloredItemStack(ItemStack stack, int stackSize, EnumDyeColor color) {
		if(canItemStackBeRecoloredByNBT(stack)) {
			ItemStack copy = stack.copy();
			copy.setCount(stackSize);
			setColor(copy, color.getColorValue());
			return copy;
		}
		if(canItemStackBeRecoloredByMetadata(stack)) return new ItemStack(stack.getItem(), stackSize, color.getMetadata());
		return ItemStack.EMPTY;
	}
	/**
	 * Checks to see if the given item stack is dye.
	 * @param stack
	 * @return
	 */
	public static boolean isItemStackDye(ItemStack stack) {return stack.getItem() instanceof ItemDye;}
	/**
	 * Gets the EnumDyeColor for the given dyeStack
	 * @param dyeStack
	 * @return
	 */
	public static EnumDyeColor getDyeColorForDye(ItemStack dyeStack) {
		if(!isItemStackDye(dyeStack)) return null;
		return EnumDyeColor.byDyeDamage(dyeStack.getMetadata());
	}
	/**
	 * Converts an integer color to RGB colors in a int array
	 * int[0] = R
	 * int[1] = G
	 * int[2] = B
	 * Simple as that.
	 * @param color
	 * @return
	 */
	public static int[] convertIntegerToRGB(int color) {
		int red = (color >> 16) & 0xFF;
		int green = (color >> 8) & 0xFF;
		int blue = color & 0xFF;
		int[] rgb = {red, green, blue};
		return rgb;
	}
	/**
	 * Converts a HEX string (used to save colors in option files)
	 * to an RGB used for drawing or whatever you want.
	 * @param hex - HEX String to convert
	 * @return - int array {red, green, blue}
	 */
	public static int[] convertHexStringToRGB(String hex) {
		int red = 0;
		int green = 0;
		int blue = 0;
    	if(!hex.equals("0")){
    		Color c2 = new Color((int)Long.parseLong(hex.substring(2), 16));
    		red = c2.getRed();
    		green = c2.getGreen(); 
    		blue = c2.getBlue();
    	}
    	int[] rgb = {red, green, blue};
    	return rgb;
	}
	/**
	 * Converts three r, g, and b values to an integer
	 * for use with minecraft parsing.
	 * @param red
	 * @param green
	 * @param blue
	 * @return
	 */
	public static int convertRGBToInteger(int red, int green, int blue) {
		int rgb = red;
		rgb = (rgb << 8) + green;
		rgb = (rgb << 8) + blue;
		return rgb;
	}
	/**
	 * Converts three r, g, and b values to an integer
	 * for use with minecraft parsing.
	 * @param rgb - rgb int array {red, blue, green} 0-255
	 * @return
	 */
	public static int convertRGBToInteger(int[] rgb) {
		int red = rgb[0];
		int green = rgb[1];
		int blue = rgb[2];
		int color = red;
		color = (color << 8) + green;
		color = (color << 8) + blue;
		return color;
	}
	/**
	 * Converts RGB to hex string
	 * @param r
	 * @param g
	 * @param b
	 * @return
	 */
	 public static String toHex(int r, int g, int b) {
		   return "0x" + toBrowserHexValue(r) + toBrowserHexValue(g) + toBrowserHexValue(b);
	 }

	 private static String toBrowserHexValue(int number) {
		 StringBuilder builder = new StringBuilder(Integer.toHexString(number & 0xff));
		 while (builder.length() < 2) {
		     builder.append("0");
		 }
		 return builder.toString();
	}

	    /**
	     * Return the color for the specified ItemStack. Will return -1 if not found.
	     */
	    public static int getColor(ItemStack stack){
	    	NBTTagCompound nbttagcompound = stack.getTagCompound();
	        if(nbttagcompound != null){
	        	NBTTagCompound nbttagcompound1 = nbttagcompound.getCompoundTag("display");
	            if(nbttagcompound1 != null && nbttagcompound1.hasKey("color", 3)){
	            	return nbttagcompound1.getInteger("color");
	            }
	        }
	        return -1;
	    }	 
}
