package com.finalkg.wsbim.common.tile;

import net.minecraft.tileentity.TileEntity;

public class TileEntityModelRenderer extends TileEntity {

}
